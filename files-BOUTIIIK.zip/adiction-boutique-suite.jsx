import { useState, useMemo, useCallback, useEffect, useRef } from "react";
import {
  LayoutDashboard, ShoppingCart, Package, Users, CreditCard, FileText,
  Plus, Search, Trash2, Edit, X, ChevronDown, MapPin, Phone, Mail,
  AlertTriangle, TrendingUp, DollarSign, BarChart3, Tag, Ruler,
  Building2, Truck, Warehouse, ArrowRightLeft, ArrowDown, ArrowUp,
  Layers, Settings, Menu, Eye, CheckCircle, Clock, XCircle,
  Map as MapIcon, Filter, Navigation, ExternalLink, Copy, Globe
} from "lucide-react";

// ═══════════════════════════════════════════════════════════════════════
// DATA STORE (In-Memory Mock — Replace with Supabase)
// ═══════════════════════════════════════════════════════════════════════
const uid = () => crypto.randomUUID();
const today = new Date().toISOString().slice(0, 10);
const daysAgo = (n) => { const d = new Date(); d.setDate(d.getDate() - n); return d.toISOString().slice(0, 10); };
const daysLater = (n) => { const d = new Date(); d.setDate(d.getDate() + n); return d.toISOString().slice(0, 10); };

// — Stores/Warehouses —
const initStores = () => [
  { id: uid(), code: "MUJERES", name: "Tienda Mujeres", address: "Jr. Pizarro 450, Trujillo", phone: "044-223344", active: true },
  { id: uid(), code: "HOMBRES", name: "Tienda Hombres", address: "Jr. Bolívar 312, Trujillo", phone: "044-556677", active: true },
];

// — Lines —
const initLines = () => [
  { id: "ln1", code: "DAMA", name: "Dama", description: "Ropa para dama", active: true, created_at: daysAgo(90) },
  { id: "ln2", code: "CABALLERO", name: "Caballero", description: "Ropa para caballero", active: true, created_at: daysAgo(90) },
  { id: "ln3", code: "NIÑOS", name: "Niños", description: "Ropa para niños", active: true, created_at: daysAgo(90) },
  { id: "ln4", code: "ACCESORIOS", name: "Accesorios", description: "Accesorios varios", active: true, created_at: daysAgo(90) },
  { id: "ln5", code: "CALZADO", name: "Calzado", description: "Zapatos y zapatillas", active: true, created_at: daysAgo(90) },
];

// — Categories —
const initCategories = () => [
  { id: "cat1", code: "BLUSAS", name: "Blusas", line_id: "ln1", description: "", active: true },
  { id: "cat2", code: "PANTALONES", name: "Pantalones", line_id: "ln1", description: "", active: true },
  { id: "cat3", code: "VESTIDOS", name: "Vestidos", line_id: "ln1", description: "", active: true },
  { id: "cat4", code: "FALDAS", name: "Faldas", line_id: "ln1", description: "", active: true },
  { id: "cat5", code: "CAMISAS", name: "Camisas", line_id: "ln2", description: "", active: true },
  { id: "cat6", code: "JEANS", name: "Jeans", line_id: "ln2", description: "", active: true },
  { id: "cat7", code: "POLOS", name: "Polos", line_id: "ln2", description: "", active: true },
  { id: "cat8", code: "CONJUNTOS", name: "Conjuntos", line_id: "ln3", description: "", active: true },
  { id: "cat9", code: "CARTERAS", name: "Carteras", line_id: "ln4", description: "", active: true },
  { id: "cat10", code: "ZAPATILLAS", name: "Zapatillas", line_id: "ln5", description: "", active: true },
];

// — Brands —
const initBrands = () => [
  { id: "br1", code: "ADICTION", name: "Adiction", description: "Marca propia", active: true },
  { id: "br2", code: "ZARA", name: "Zara", description: "", active: true },
  { id: "br3", code: "HM", name: "H&M", description: "", active: true },
  { id: "br4", code: "F21", name: "Forever 21", description: "", active: true },
  { id: "br5", code: "MANGO", name: "Mango", description: "", active: true },
];

// — Sizes —
const initSizes = () => [
  { id: "sz1", code: "XS", name: "Extra Small", category_id: null, sort_order: 1, active: true },
  { id: "sz2", code: "S", name: "Small", category_id: null, sort_order: 2, active: true },
  { id: "sz3", code: "M", name: "Medium", category_id: null, sort_order: 3, active: true },
  { id: "sz4", code: "L", name: "Large", category_id: null, sort_order: 4, active: true },
  { id: "sz5", code: "XL", name: "Extra Large", category_id: null, sort_order: 5, active: true },
  { id: "sz6", code: "XXL", name: "Double XL", category_id: null, sort_order: 6, active: true },
  { id: "sz7", code: "UNICA", name: "Talla Única", category_id: null, sort_order: 7, active: true },
  { id: "sz8", code: "28", name: "28", category_id: "cat2", sort_order: 1, active: true },
  { id: "sz9", code: "30", name: "30", category_id: "cat2", sort_order: 2, active: true },
  { id: "sz10", code: "32", name: "32", category_id: "cat2", sort_order: 3, active: true },
  { id: "sz11", code: "34", name: "34", category_id: "cat6", sort_order: 1, active: true },
  { id: "sz12", code: "36", name: "36", category_id: "cat6", sort_order: 2, active: true },
];

// — Suppliers —
const initSuppliers = () => [
  { id: "sup1", code: "GAMARRA01", name: "Textiles Gamarra SAC", contact_name: "José Ramos", phone: "987654321", email: "jose@gamarra.com", address: "Jr. Gamarra 1250, La Victoria, Lima", active: true },
  { id: "sup2", code: "IMPORTA01", name: "Importaciones Chen", contact_name: "Wei Chen", phone: "912345678", email: "wei@importchen.com", address: "Jr. Ucayali 350, Cercado de Lima", active: true },
  { id: "sup3", code: "MODA01", name: "Distribuidora Moda Total", contact_name: "María López", phone: "945678123", email: "maria@modatotal.pe", address: "Av. Grau 980, La Victoria, Lima", active: true },
];

// — Products —
const initProducts = () => [
  { id: "p1", barcode: "7501001001", name: "Blusa Floral Manga Corta", description: "", line_id: "ln1", category_id: "cat1", brand_id: "br1", supplier_id: "sup1", size: "M", color: "Rosa", purchase_price: 25, price: 59.9, min_stock: 5, active: true },
  { id: "p2", barcode: "7501001002", name: "Pantalón Palazzo Negro", description: "", line_id: "ln1", category_id: "cat2", brand_id: "br1", supplier_id: "sup1", size: "28", color: "Negro", purchase_price: 35, price: 89.9, min_stock: 3, active: true },
  { id: "p3", barcode: "7501001003", name: "Vestido Cocktail Rojo", description: "", line_id: "ln1", category_id: "cat3", brand_id: "br5", supplier_id: "sup3", size: "S", color: "Rojo", purchase_price: 45, price: 129.9, min_stock: 2, active: true },
  { id: "p4", barcode: "7501001004", name: "Falda Plisada Beige", description: "", line_id: "ln1", category_id: "cat4", brand_id: "br1", supplier_id: "sup1", size: "M", color: "Beige", purchase_price: 22, price: 55.9, min_stock: 4, active: true },
  { id: "p5", barcode: "7501002001", name: "Camisa Slim Fit Blanca", description: "", line_id: "ln2", category_id: "cat5", brand_id: "br2", supplier_id: "sup2", size: "L", color: "Blanco", purchase_price: 30, price: 79.9, min_stock: 5, active: true },
  { id: "p6", barcode: "7501002002", name: "Jean Skinny Azul", description: "", line_id: "ln2", category_id: "cat6", brand_id: "br3", supplier_id: "sup2", size: "32", color: "Azul", purchase_price: 40, price: 99.9, min_stock: 3, active: true },
  { id: "p7", barcode: "7501002003", name: "Polo Básico Negro", description: "", line_id: "ln2", category_id: "cat7", brand_id: "br1", supplier_id: "sup1", size: "M", color: "Negro", purchase_price: 15, price: 39.9, min_stock: 8, active: true },
  { id: "p8", barcode: "7501003001", name: "Conjunto Niña Flores", description: "", line_id: "ln3", category_id: "cat8", brand_id: "br4", supplier_id: "sup3", size: "S", color: "Multicolor", purchase_price: 20, price: 49.9, min_stock: 4, active: true },
  { id: "p9", barcode: "7501004001", name: "Cartera Cuero Café", description: "", line_id: "ln4", category_id: "cat9", brand_id: "br5", supplier_id: "sup3", size: "UNICA", color: "Café", purchase_price: 35, price: 85.9, min_stock: 3, active: true },
  { id: "p10", barcode: "7501005001", name: "Zapatillas Urban White", description: "", line_id: "ln5", category_id: "cat10", brand_id: "br3", supplier_id: "sup2", size: "38", color: "Blanco", purchase_price: 50, price: 119.9, min_stock: 3, active: true },
  { id: "p11", barcode: "7501001005", name: "Blusa Off-Shoulder Blanca", description: "", line_id: "ln1", category_id: "cat1", brand_id: "br5", supplier_id: "sup3", size: "S", color: "Blanco", purchase_price: 28, price: 65.9, min_stock: 4, active: true },
  { id: "p12", barcode: "7501002004", name: "Camisa Leñadora Cuadros", description: "", line_id: "ln2", category_id: "cat5", brand_id: "br3", supplier_id: "sup2", size: "XL", color: "Rojo/Negro", purchase_price: 32, price: 75.9, min_stock: 3, active: true },
];

// — Stock per warehouse —
const initStock = () => [
  { id: uid(), warehouse_id: "MUJERES", product_id: "p1", quantity: 15 },
  { id: uid(), warehouse_id: "MUJERES", product_id: "p2", quantity: 8 },
  { id: uid(), warehouse_id: "MUJERES", product_id: "p3", quantity: 4 },
  { id: uid(), warehouse_id: "MUJERES", product_id: "p4", quantity: 12 },
  { id: uid(), warehouse_id: "MUJERES", product_id: "p8", quantity: 6 },
  { id: uid(), warehouse_id: "MUJERES", product_id: "p9", quantity: 3 },
  { id: uid(), warehouse_id: "MUJERES", product_id: "p11", quantity: 10 },
  { id: uid(), warehouse_id: "HOMBRES", product_id: "p5", quantity: 12 },
  { id: uid(), warehouse_id: "HOMBRES", product_id: "p6", quantity: 7 },
  { id: uid(), warehouse_id: "HOMBRES", product_id: "p7", quantity: 20 },
  { id: uid(), warehouse_id: "HOMBRES", product_id: "p10", quantity: 5 },
  { id: uid(), warehouse_id: "HOMBRES", product_id: "p12", quantity: 9 },
  { id: uid(), warehouse_id: "MUJERES", product_id: "p10", quantity: 2 },
  { id: uid(), warehouse_id: "HOMBRES", product_id: "p9", quantity: 4 },
];

// — Inventory Movements —
const initMovements = () => [
  { id: uid(), warehouse_id: "MUJERES", product_id: "p1", type: "ENTRADA", quantity: 20, reason: "Compra inicial", created_at: daysAgo(60) },
  { id: uid(), warehouse_id: "MUJERES", product_id: "p1", type: "SALIDA", quantity: 5, reason: "Venta", created_at: daysAgo(30) },
  { id: uid(), warehouse_id: "HOMBRES", product_id: "p5", type: "ENTRADA", quantity: 15, reason: "Compra inicial", created_at: daysAgo(55) },
  { id: uid(), warehouse_id: "HOMBRES", product_id: "p6", type: "ENTRADA", quantity: 10, reason: "Reposición", created_at: daysAgo(20) },
  { id: uid(), warehouse_id: "MUJERES", product_id: "p3", type: "AJUSTE", quantity: -1, reason: "Merma", created_at: daysAgo(10) },
  { id: uid(), warehouse_id: "HOMBRES", product_id: "p7", type: "TRANSFERENCIA_IN", quantity: 5, reason: "Transferencia desde Mujeres", created_at: daysAgo(5) },
];

// — Clients —
const initClients = () => [
  { id: "c1", dni: "45678912", name: "María García López", phone: "976543210", email: "maria@gmail.com", address: "Av. España 1520, Trujillo", lat: -8.1116, lng: -79.0288, credit_limit: 1000, credit_used: 350, birthday: "1990-03-15", google_maps_url: "https://www.google.com/maps/@-8.1116,-79.0288,17z", active: true },
  { id: "c2", dni: "32165498", name: "Carlos Ruiz Torres", phone: "945612378", email: "carlos@gmail.com", address: "Jr. Pizarro 850, Trujillo", lat: -8.1090, lng: -79.0215, credit_limit: 800, credit_used: 520, birthday: "1985-07-22", google_maps_url: "https://www.google.com/maps/@-8.1090,-79.0215,17z", active: true },
  { id: "c3", dni: "78945612", name: "Ana Sánchez Vega", phone: "987123456", email: "ana@gmail.com", address: "Urb. El Golf, Trujillo", lat: -8.1250, lng: -79.0440, credit_limit: 1500, credit_used: 200, birthday: "1992-11-08", google_maps_url: "https://www.google.com/maps/@-8.1250,-79.0440,17z", active: true },
  { id: "c4", dni: "65432198", name: "Pedro Mendoza Ríos", phone: "912345987", email: "pedro@gmail.com", address: "Av. Mansiche 420, Trujillo", lat: -8.0980, lng: -79.0350, credit_limit: 600, credit_used: 600, birthday: "1988-01-30", google_maps_url: "https://www.google.com/maps/@-8.0980,-79.0350,17z", active: true },
  { id: "c5", dni: "11223344", name: "Lucía Vargas Díaz", phone: "934567890", email: "lucia@gmail.com", address: "Urb. Primavera, Trujillo", lat: -8.1320, lng: -79.0180, credit_limit: 1200, credit_used: 450, birthday: "1995-06-12", google_maps_url: "https://www.google.com/maps/@-8.1320,-79.0180,17z", active: true },
  { id: "c6", dni: "99887766", name: "Roberto Flores Castro", phone: "956789012", email: "roberto@gmail.com", address: "Av. América Norte 650, Trujillo", lat: -8.0950, lng: -79.0410, credit_limit: 500, credit_used: 0, birthday: "1991-09-25", google_maps_url: "https://www.google.com/maps/@-8.0950,-79.0410,17z", active: true },
];

// — Sales —
const initSales = () => [
  { id: "s1", sale_number: "V-0001", store_id: "MUJERES", client_id: null, sale_type: "CONTADO", subtotal: 59.9, discount: 0, total: 59.9, payment_status: "PAID", created_at: daysAgo(45) },
  { id: "s2", sale_number: "V-0002", store_id: "MUJERES", client_id: "c1", sale_type: "CREDITO", subtotal: 219.8, discount: 0, total: 219.8, payment_status: "PARTIAL", created_at: daysAgo(40) },
  { id: "s3", sale_number: "V-0003", store_id: "HOMBRES", client_id: "c2", sale_type: "CREDITO", subtotal: 179.8, discount: 0, total: 179.8, payment_status: "PENDING", created_at: daysAgo(35) },
  { id: "s4", sale_number: "V-0004", store_id: "MUJERES", client_id: null, sale_type: "CONTADO", subtotal: 129.9, discount: 10, total: 119.9, payment_status: "PAID", created_at: daysAgo(20) },
  { id: "s5", sale_number: "V-0005", store_id: "HOMBRES", client_id: "c4", sale_type: "CREDITO", subtotal: 199.8, discount: 0, total: 199.8, payment_status: "PARTIAL", created_at: daysAgo(60) },
  { id: "s6", sale_number: "V-0006", store_id: "MUJERES", client_id: "c5", sale_type: "CREDITO", subtotal: 155.8, discount: 0, total: 155.8, payment_status: "PARTIAL", created_at: daysAgo(50) },
];

// — Installments —
const initInstallments = () => [
  { id: "i1", plan_id: "pl1", installment_number: 1, amount: 73.27, due_date: daysAgo(10), paid_amount: 73.27, status: "PAID", paid_at: daysAgo(9) },
  { id: "i2", plan_id: "pl1", installment_number: 2, amount: 73.27, due_date: daysLater(20), paid_amount: 0, status: "PENDING" },
  { id: "i3", plan_id: "pl1", installment_number: 3, amount: 73.26, due_date: daysLater(50), paid_amount: 0, status: "PENDING" },
  { id: "i4", plan_id: "pl2", installment_number: 1, amount: 89.9, due_date: daysAgo(5), paid_amount: 0, status: "OVERDUE" },
  { id: "i5", plan_id: "pl2", installment_number: 2, amount: 89.9, due_date: daysLater(25), paid_amount: 0, status: "PENDING" },
  { id: "i6", plan_id: "pl3", installment_number: 1, amount: 66.6, due_date: daysAgo(30), paid_amount: 66.6, status: "PAID", paid_at: daysAgo(28) },
  { id: "i7", plan_id: "pl3", installment_number: 2, amount: 66.6, due_date: daysAgo(1), paid_amount: 30, status: "OVERDUE" },
  { id: "i8", plan_id: "pl3", installment_number: 3, amount: 66.6, due_date: daysLater(29), paid_amount: 0, status: "PENDING" },
  { id: "i9", plan_id: "pl4", installment_number: 1, amount: 77.9, due_date: daysAgo(20), paid_amount: 77.9, status: "PAID", paid_at: daysAgo(19) },
  { id: "i10", plan_id: "pl4", installment_number: 2, amount: 77.9, due_date: daysLater(10), paid_amount: 40, status: "PARTIAL" },
];

const initCreditPlans = () => [
  { id: "pl1", sale_id: "s2", client_id: "c1", total_amount: 219.8, installments_count: 3, installment_amount: 73.27, status: "ACTIVE" },
  { id: "pl2", sale_id: "s3", client_id: "c2", total_amount: 179.8, installments_count: 2, installment_amount: 89.9, status: "ACTIVE" },
  { id: "pl3", sale_id: "s5", client_id: "c4", total_amount: 199.8, installments_count: 3, installment_amount: 66.6, status: "ACTIVE" },
  { id: "pl4", sale_id: "s6", client_id: "c5", total_amount: 155.8, installments_count: 2, installment_amount: 77.9, status: "ACTIVE" },
];

const initCollectionActions = () => [
  { id: uid(), client_id: "c2", client_name: "Carlos Ruiz Torres", action_type: "LLAMADA", result: "PROMESA_PAGO", payment_promise_date: daysLater(5), notes: "Dice que pagará el viernes", created_at: daysAgo(2) },
  { id: uid(), client_id: "c4", client_name: "Pedro Mendoza Ríos", action_type: "WHATSAPP", result: "NO_RESPONDE", notes: "No contesta mensajes", created_at: daysAgo(1) },
  { id: uid(), client_id: "c4", client_name: "Pedro Mendoza Ríos", action_type: "VISITA", result: "PROMESA_PAGO", payment_promise_date: daysLater(3), notes: "Visitado en domicilio", created_at: today },
];

// ═══════════════════════════════════════════════════════════════════════
// GOOGLE MAPS URL PARSER
// ═══════════════════════════════════════════════════════════════════════
function parseGoogleMapsUrl(url) {
  if (!url) return null;
  try {
    // Format: @lat,lng
    let m = url.match(/@(-?\d+\.?\d*),(-?\d+\.?\d*)/);
    if (m) return { lat: parseFloat(m[1]), lng: parseFloat(m[2]) };
    // Format: ?q=lat,lng
    m = url.match(/[?&]q=(-?\d+\.?\d*),(-?\d+\.?\d*)/);
    if (m) return { lat: parseFloat(m[1]), lng: parseFloat(m[2]) };
    // Format: /place/.../ or ll=lat,lng
    m = url.match(/ll=(-?\d+\.?\d*),(-?\d+\.?\d*)/);
    if (m) return { lat: parseFloat(m[1]), lng: parseFloat(m[2]) };
    // Format: !3d...!4d... (embedded)
    m = url.match(/!3d(-?\d+\.?\d*)!4d(-?\d+\.?\d*)/);
    if (m) return { lat: parseFloat(m[1]), lng: parseFloat(m[2]) };
  } catch { }
  return null;
}

// ═══════════════════════════════════════════════════════════════════════
// SHARED UI COMPONENTS
// ═══════════════════════════════════════════════════════════════════════
const fmt = (n) => `S/ ${Number(n || 0).toFixed(2)}`;
const fmtDate = (d) => d ? new Date(d + "T12:00:00").toLocaleDateString("es-PE", { day: "2-digit", month: "short", year: "numeric" }) : "—";
const diffDays = (d) => { const t = new Date(); const dd = new Date(d + "T12:00:00"); return Math.floor((t - dd) / 86400000); };

const Badge = ({ children, color = "amber" }) => {
  const colors = {
    amber: "bg-amber-500/20 text-amber-300 border-amber-500/30",
    red: "bg-red-500/20 text-red-300 border-red-500/30",
    green: "bg-emerald-500/20 text-emerald-300 border-emerald-500/30",
    blue: "bg-blue-500/20 text-blue-300 border-blue-500/30",
    gray: "bg-gray-500/20 text-gray-400 border-gray-500/30",
    purple: "bg-purple-500/20 text-purple-300 border-purple-500/30",
    pink: "bg-pink-500/20 text-pink-300 border-pink-500/30",
    cyan: "bg-cyan-500/20 text-cyan-300 border-cyan-500/30",
  };
  return <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${colors[color] || colors.amber}`}>{children}</span>;
};

const Stat = ({ icon: Icon, label, value, sub, color = "amber" }) => (
  <div className="bg-gray-800/80 backdrop-blur rounded-xl border border-gray-700/50 p-4 hover:border-amber-500/30 transition-all">
    <div className="flex items-center gap-3">
      <div className={`p-2 rounded-lg bg-${color}-500/15`}><Icon size={18} className={`text-${color}-400`} /></div>
      <div className="min-w-0 flex-1">
        <p className="text-xs text-gray-500 uppercase tracking-wider">{label}</p>
        <p className="text-xl font-bold text-gray-100 truncate">{value}</p>
        {sub && <p className="text-xs text-gray-500 mt-0.5">{sub}</p>}
      </div>
    </div>
  </div>
);

const EmptyState = ({ icon: Icon, title, sub }) => (
  <div className="text-center py-12 text-gray-500">
    <Icon size={40} className="mx-auto mb-3 opacity-40" />
    <p className="font-medium">{title}</p>
    {sub && <p className="text-sm mt-1">{sub}</p>}
  </div>
);

const Btn = ({ children, onClick, variant = "primary", size = "md", className = "", disabled, ...props }) => {
  const base = "inline-flex items-center justify-center gap-2 font-medium rounded-lg transition-all active:scale-95 disabled:opacity-50 disabled:pointer-events-none";
  const sizes = { sm: "px-3 py-1.5 text-xs", md: "px-4 py-2 text-sm", lg: "px-6 py-3 text-base" };
  const variants = {
    primary: "bg-amber-500 text-gray-900 hover:bg-amber-400 shadow-lg shadow-amber-500/20",
    secondary: "bg-gray-700 text-gray-200 hover:bg-gray-600 border border-gray-600",
    danger: "bg-red-600 text-white hover:bg-red-500",
    ghost: "text-gray-400 hover:text-gray-200 hover:bg-gray-800",
  };
  return <button onClick={onClick} disabled={disabled} className={`${base} ${sizes[size]} ${variants[variant]} ${className}`} {...props}>{children}</button>;
};

const SearchInput = ({ value, onChange, placeholder = "Buscar..." }) => (
  <div className="relative">
    <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
    <input value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
      className="w-full pl-10 pr-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-sm text-gray-200 placeholder-gray-500 focus:outline-none focus:border-amber-500/50 focus:ring-1 focus:ring-amber-500/20" />
  </div>
);

const Modal = ({ open, onClose, title, children, wide }) => {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="fixed inset-0 bg-black/70 backdrop-blur-sm" />
      <div className={`relative bg-gray-900 border border-gray-700 rounded-2xl shadow-2xl w-full ${wide ? "max-w-4xl" : "max-w-lg"} max-h-[90vh] overflow-y-auto`}
        onClick={e => e.stopPropagation()}>
        <div className="sticky top-0 bg-gray-900/95 backdrop-blur border-b border-gray-800 px-6 py-4 flex items-center justify-between z-10">
          <h3 className="text-lg font-bold text-gray-100">{title}</h3>
          <button onClick={onClose} className="p-1.5 hover:bg-gray-800 rounded-lg text-gray-500 hover:text-gray-300"><X size={18} /></button>
        </div>
        <div className="p-6">{children}</div>
      </div>
    </div>
  );
};

const TabBar = ({ tabs, active, onChange }) => (
  <div className="flex gap-1 bg-gray-800/50 rounded-xl p-1 overflow-x-auto">
    {tabs.map(t => (
      <button key={t.key} onClick={() => onChange(t.key)}
        className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${active === t.key ? "bg-amber-500 text-gray-900 shadow-lg" : "text-gray-400 hover:text-gray-200 hover:bg-gray-700/50"}`}>
        {t.icon && <span className="mr-1.5">{t.icon}</span>}{t.label}{t.count != null ? ` (${t.count})` : ""}
      </button>
    ))}
  </div>
);

const Field = ({ label, children, required }) => (
  <div>
    <label className="block text-xs font-medium text-gray-400 mb-1">{label}{required && <span className="text-red-400 ml-0.5">*</span>}</label>
    {children}
  </div>
);

const Input = ({ value, onChange, type = "text", placeholder, className = "", ...props }) => (
  <input type={type} value={value ?? ""} onChange={e => onChange(type === "number" ? (e.target.value === "" ? "" : Number(e.target.value)) : e.target.value)}
    placeholder={placeholder}
    className={`w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-sm text-gray-200 placeholder-gray-500 focus:outline-none focus:border-amber-500/50 focus:ring-1 focus:ring-amber-500/20 ${className}`} {...props} />
);

const Select = ({ value, onChange, options, placeholder = "Seleccionar..." }) => (
  <select value={value ?? ""} onChange={e => onChange(e.target.value)}
    className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-sm text-gray-200 focus:outline-none focus:border-amber-500/50">
    <option value="">{placeholder}</option>
    {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
  </select>
);

const Toggle = ({ checked, onChange, label }) => (
  <label className="flex items-center gap-2 cursor-pointer">
    <div className={`w-10 h-5 rounded-full transition-colors relative ${checked ? "bg-amber-500" : "bg-gray-700"}`}
      onClick={() => onChange(!checked)}>
      <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform ${checked ? "translate-x-5" : "translate-x-0.5"}`} />
    </div>
    {label && <span className="text-sm text-gray-300">{label}</span>}
  </label>
);

// ═══════════════════════════════════════════════════════════════════════
// MODULE: DASHBOARD
// ═══════════════════════════════════════════════════════════════════════
function Dashboard({ sales, installments, stock, products, clients }) {
  const totalSales = sales.reduce((s, v) => s + v.total, 0);
  const pendingCredit = installments.filter(i => i.status !== "PAID").reduce((s, i) => s + (i.amount - i.paid_amount), 0);
  const overdueDebt = installments.filter(i => i.status === "OVERDUE").reduce((s, i) => s + (i.amount - i.paid_amount), 0);
  const totalStock = stock.reduce((s, st) => s + st.quantity, 0);
  const lowStockItems = useMemo(() => {
    return products.filter(p => {
      const qty = stock.filter(s => s.product_id === p.id).reduce((s, st) => s + st.quantity, 0);
      return qty <= p.min_stock && p.active;
    });
  }, [products, stock]);
  const recentSales = sales.slice().sort((a, b) => b.created_at.localeCompare(a.created_at)).slice(0, 5);
  const overdueInst = installments.filter(i => i.status === "OVERDUE" || (i.status === "PARTIAL" && diffDays(i.due_date) > 0));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-100">Dashboard</h1>
          <p className="text-sm text-gray-500">Adiction Boutique — Resumen del negocio</p>
        </div>
        <p className="text-xs text-gray-600">{new Date().toLocaleDateString("es-PE", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}</p>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Stat icon={DollarSign} label="Ventas Totales" value={fmt(totalSales)} color="green" />
        <Stat icon={CreditCard} label="Créditos Pendientes" value={fmt(pendingCredit)} color="blue" />
        <Stat icon={AlertTriangle} label="Deuda Vencida" value={fmt(overdueDebt)} color="red" />
        <Stat icon={Package} label="Stock Total" value={totalStock + " uds."} sub={`${products.length} productos`} color="amber" />
      </div>
      <div className="grid lg:grid-cols-2 gap-6">
        <div className="bg-gray-800/80 rounded-xl border border-gray-700/50 p-5">
          <h3 className="font-semibold text-gray-200 mb-4">Ventas Recientes</h3>
          {recentSales.length === 0 ? <EmptyState icon={ShoppingCart} title="Sin ventas" /> : (
            <div className="space-y-3">{recentSales.map(s => (
              <div key={s.id} className="flex items-center justify-between p-3 bg-gray-900/50 rounded-lg">
                <div>
                  <span className="text-sm font-medium text-gray-200">{s.sale_number}</span>
                  <div className="flex gap-2 mt-1">
                    <Badge color={s.store_id === "MUJERES" ? "pink" : "blue"}>{s.store_id}</Badge>
                    <Badge color={s.sale_type === "CREDITO" ? "purple" : "green"}>{s.sale_type}</Badge>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-sm font-bold text-amber-400">{fmt(s.total)}</span>
                  <p className="text-xs text-gray-500">{fmtDate(s.created_at)}</p>
                </div>
              </div>
            ))}</div>
          )}
        </div>
        <div className="space-y-6">
          <div className="bg-gray-800/80 rounded-xl border border-gray-700/50 p-5">
            <h3 className="font-semibold text-gray-200 mb-4 flex items-center gap-2"><AlertTriangle size={16} className="text-red-400" />Cuotas Vencidas ({overdueInst.length})</h3>
            {overdueInst.length === 0 ? <p className="text-sm text-gray-500">Sin cuotas vencidas 🎉</p> : (
              <div className="space-y-2">{overdueInst.slice(0, 4).map(i => (
                <div key={i.id} className="flex items-center justify-between p-2 bg-red-500/5 rounded-lg border border-red-500/10">
                  <div>
                    <span className="text-xs text-gray-400">Cuota #{i.installment_number}</span>
                    <p className="text-sm text-gray-200">{fmt(i.amount - i.paid_amount)} pendiente</p>
                  </div>
                  <Badge color="red">{diffDays(i.due_date)} días</Badge>
                </div>
              ))}</div>
            )}
          </div>
          {lowStockItems.length > 0 && (
            <div className="bg-gray-800/80 rounded-xl border border-gray-700/50 p-5">
              <h3 className="font-semibold text-gray-200 mb-4 flex items-center gap-2"><Package size={16} className="text-amber-400" />Stock Bajo ({lowStockItems.length})</h3>
              <div className="space-y-2">{lowStockItems.slice(0, 4).map(p => {
                const qty = stock.filter(s => s.product_id === p.id).reduce((s, st) => s + st.quantity, 0);
                return (
                  <div key={p.id} className="flex items-center justify-between p-2 bg-amber-500/5 rounded-lg border border-amber-500/10">
                    <span className="text-sm text-gray-200 truncate">{p.name}</span>
                    <Badge color={qty === 0 ? "red" : "amber"}>{qty} uds.</Badge>
                  </div>
                );
              })}</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// MODULE: CATALOGS (Lines, Categories, Brands, Sizes, Suppliers)
// ═══════════════════════════════════════════════════════════════════════
function CatalogsModule({ lines, setLines, categories, setCategories, brands, setBrands, sizes, setSizes, suppliers, setSuppliers }) {
  const [tab, setTab] = useState("lines");
  const [modal, setModal] = useState(null); // { type, item }
  const [search, setSearch] = useState("");

  const tabs = [
    { key: "lines", label: "Líneas", count: lines.length },
    { key: "categories", label: "Categorías", count: categories.length },
    { key: "brands", label: "Marcas", count: brands.length },
    { key: "sizes", label: "Tallas", count: sizes.length },
    { key: "suppliers", label: "Proveedores", count: suppliers.length },
  ];

  // Generic CRUD handlers
  function handleSave(type, item) {
    const setters = { lines: setLines, categories: setCategories, brands: setBrands, sizes: setSizes, suppliers: setSuppliers };
    const setter = setters[type];
    setter(prev => {
      const exists = prev.find(x => x.id === item.id);
      if (exists) return prev.map(x => x.id === item.id ? { ...x, ...item } : x);
      return [...prev, { ...item, id: item.id || uid(), active: true, created_at: today }];
    });
    setModal(null);
  }

  function handleDelete(type, id) {
    const setters = { lines: setLines, categories: setCategories, brands: setBrands, sizes: setSizes, suppliers: setSuppliers };
    setters[type](prev => prev.filter(x => x.id !== id));
  }

  function renderTable() {
    const s = search.toLowerCase();
    switch (tab) {
      case "lines": {
        const data = lines.filter(x => x.name.toLowerCase().includes(s) || x.code.toLowerCase().includes(s));
        return (
          <table className="w-full text-sm"><thead><tr className="text-left text-xs text-gray-500 uppercase">
            <th className="pb-3 pl-4">Código</th><th className="pb-3">Nombre</th><th className="pb-3">Descripción</th><th className="pb-3">Estado</th><th className="pb-3 text-right pr-4">Acciones</th>
          </tr></thead><tbody>{data.map(x => (
            <tr key={x.id} className="border-t border-gray-800 hover:bg-gray-800/50">
              <td className="py-3 pl-4 font-mono text-amber-400">{x.code}</td>
              <td className="py-3 text-gray-200">{x.name}</td>
              <td className="py-3 text-gray-400">{x.description || "—"}</td>
              <td className="py-3"><Badge color={x.active ? "green" : "gray"}>{x.active ? "Activo" : "Inactivo"}</Badge></td>
              <td className="py-3 pr-4 text-right space-x-1">
                <Btn size="sm" variant="ghost" onClick={() => setModal({ type: "lines", item: x })}><Edit size={14} /></Btn>
                <Btn size="sm" variant="ghost" onClick={() => handleDelete("lines", x.id)}><Trash2 size={14} /></Btn>
              </td>
            </tr>
          ))}</tbody></table>
        );
      }
      case "categories": {
        const data = categories.filter(x => x.name.toLowerCase().includes(s) || x.code.toLowerCase().includes(s));
        return (
          <table className="w-full text-sm"><thead><tr className="text-left text-xs text-gray-500 uppercase">
            <th className="pb-3 pl-4">Código</th><th className="pb-3">Nombre</th><th className="pb-3">Línea</th><th className="pb-3">Estado</th><th className="pb-3 text-right pr-4">Acciones</th>
          </tr></thead><tbody>{data.map(x => (
            <tr key={x.id} className="border-t border-gray-800 hover:bg-gray-800/50">
              <td className="py-3 pl-4 font-mono text-amber-400">{x.code}</td>
              <td className="py-3 text-gray-200">{x.name}</td>
              <td className="py-3 text-gray-400">{lines.find(l => l.id === x.line_id)?.name || "—"}</td>
              <td className="py-3"><Badge color={x.active ? "green" : "gray"}>{x.active ? "Activo" : "Inactivo"}</Badge></td>
              <td className="py-3 pr-4 text-right space-x-1">
                <Btn size="sm" variant="ghost" onClick={() => setModal({ type: "categories", item: x })}><Edit size={14} /></Btn>
                <Btn size="sm" variant="ghost" onClick={() => handleDelete("categories", x.id)}><Trash2 size={14} /></Btn>
              </td>
            </tr>
          ))}</tbody></table>
        );
      }
      case "brands": {
        const data = brands.filter(x => x.name.toLowerCase().includes(s) || x.code.toLowerCase().includes(s));
        return (
          <table className="w-full text-sm"><thead><tr className="text-left text-xs text-gray-500 uppercase">
            <th className="pb-3 pl-4">Código</th><th className="pb-3">Nombre</th><th className="pb-3">Descripción</th><th className="pb-3">Estado</th><th className="pb-3 text-right pr-4">Acciones</th>
          </tr></thead><tbody>{data.map(x => (
            <tr key={x.id} className="border-t border-gray-800 hover:bg-gray-800/50">
              <td className="py-3 pl-4 font-mono text-amber-400">{x.code}</td>
              <td className="py-3 text-gray-200">{x.name}</td>
              <td className="py-3 text-gray-400">{x.description || "—"}</td>
              <td className="py-3"><Badge color={x.active ? "green" : "gray"}>{x.active ? "Activo" : "Inactivo"}</Badge></td>
              <td className="py-3 pr-4 text-right space-x-1">
                <Btn size="sm" variant="ghost" onClick={() => setModal({ type: "brands", item: x })}><Edit size={14} /></Btn>
                <Btn size="sm" variant="ghost" onClick={() => handleDelete("brands", x.id)}><Trash2 size={14} /></Btn>
              </td>
            </tr>
          ))}</tbody></table>
        );
      }
      case "sizes": {
        const data = sizes.filter(x => x.name.toLowerCase().includes(s) || x.code.toLowerCase().includes(s));
        return (
          <table className="w-full text-sm"><thead><tr className="text-left text-xs text-gray-500 uppercase">
            <th className="pb-3 pl-4">Código</th><th className="pb-3">Nombre</th><th className="pb-3">Categoría</th><th className="pb-3">Orden</th><th className="pb-3">Estado</th><th className="pb-3 text-right pr-4">Acciones</th>
          </tr></thead><tbody>{data.map(x => (
            <tr key={x.id} className="border-t border-gray-800 hover:bg-gray-800/50">
              <td className="py-3 pl-4 font-mono text-amber-400">{x.code}</td>
              <td className="py-3 text-gray-200">{x.name}</td>
              <td className="py-3 text-gray-400">{categories.find(c => c.id === x.category_id)?.name || "General"}</td>
              <td className="py-3 text-gray-400">{x.sort_order}</td>
              <td className="py-3"><Badge color={x.active ? "green" : "gray"}>{x.active ? "Activo" : "Inactivo"}</Badge></td>
              <td className="py-3 pr-4 text-right space-x-1">
                <Btn size="sm" variant="ghost" onClick={() => setModal({ type: "sizes", item: x })}><Edit size={14} /></Btn>
                <Btn size="sm" variant="ghost" onClick={() => handleDelete("sizes", x.id)}><Trash2 size={14} /></Btn>
              </td>
            </tr>
          ))}</tbody></table>
        );
      }
      case "suppliers": {
        const data = suppliers.filter(x => x.name.toLowerCase().includes(s) || x.code.toLowerCase().includes(s));
        return (
          <table className="w-full text-sm"><thead><tr className="text-left text-xs text-gray-500 uppercase">
            <th className="pb-3 pl-4">Código</th><th className="pb-3">Nombre</th><th className="pb-3">Contacto</th><th className="pb-3">Teléfono</th><th className="pb-3">Email</th><th className="pb-3 text-right pr-4">Acciones</th>
          </tr></thead><tbody>{data.map(x => (
            <tr key={x.id} className="border-t border-gray-800 hover:bg-gray-800/50">
              <td className="py-3 pl-4 font-mono text-amber-400">{x.code}</td>
              <td className="py-3 text-gray-200">{x.name}</td>
              <td className="py-3 text-gray-400">{x.contact_name || "—"}</td>
              <td className="py-3 text-gray-400">{x.phone || "—"}</td>
              <td className="py-3 text-gray-400">{x.email || "—"}</td>
              <td className="py-3 pr-4 text-right space-x-1">
                <Btn size="sm" variant="ghost" onClick={() => setModal({ type: "suppliers", item: x })}><Edit size={14} /></Btn>
                <Btn size="sm" variant="ghost" onClick={() => handleDelete("suppliers", x.id)}><Trash2 size={14} /></Btn>
              </td>
            </tr>
          ))}</tbody></table>
        );
      }
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div><h1 className="text-2xl font-bold text-gray-100">Catálogos</h1><p className="text-sm text-gray-500">Líneas, categorías, marcas, tallas y proveedores</p></div>
        <Btn onClick={() => setModal({ type: tab, item: {} })}><Plus size={16} />Nuevo</Btn>
      </div>
      <TabBar tabs={tabs} active={tab} onChange={t => { setTab(t); setSearch(""); }} />
      <div className="max-w-sm"><SearchInput value={search} onChange={setSearch} /></div>
      <div className="bg-gray-800/50 rounded-xl border border-gray-700/50 overflow-x-auto">{renderTable()}</div>

      {/* Modal Forms */}
      <Modal open={!!modal} onClose={() => setModal(null)} title={modal?.item?.id ? "Editar" : "Nuevo"}>
        {modal && <CatalogForm type={modal.type} item={modal.item} lines={lines} categories={categories}
          onSave={item => handleSave(modal.type, item)} onClose={() => setModal(null)} />}
      </Modal>
    </div>
  );
}

function CatalogForm({ type, item, lines, categories, onSave, onClose }) {
  const [form, setForm] = useState({ ...item });
  const set = (k, v) => setForm(p => ({ ...p, [k]: v }));

  function handleSubmit() {
    if (!form.code || !form.name) return;
    onSave(form);
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <Field label="Código" required><Input value={form.code} onChange={v => set("code", v.toUpperCase())} placeholder="CODIGO" /></Field>
        <Field label="Nombre" required><Input value={form.name} onChange={v => set("name", v)} placeholder="Nombre" /></Field>
      </div>
      {type === "categories" && (
        <Field label="Línea"><Select value={form.line_id} onChange={v => set("line_id", v)} options={lines.map(l => ({ value: l.id, label: l.name }))} /></Field>
      )}
      {type === "sizes" && (
        <div className="grid grid-cols-2 gap-4">
          <Field label="Categoría"><Select value={form.category_id} onChange={v => set("category_id", v)} options={[{ value: "", label: "General" }, ...categories.map(c => ({ value: c.id, label: c.name }))]} /></Field>
          <Field label="Orden"><Input type="number" value={form.sort_order} onChange={v => set("sort_order", v)} /></Field>
        </div>
      )}
      {type === "suppliers" && (
        <>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Contacto"><Input value={form.contact_name} onChange={v => set("contact_name", v)} /></Field>
            <Field label="Teléfono"><Input value={form.phone} onChange={v => set("phone", v)} /></Field>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Email"><Input value={form.email} onChange={v => set("email", v)} /></Field>
            <Field label="Dirección"><Input value={form.address} onChange={v => set("address", v)} /></Field>
          </div>
        </>
      )}
      {(type === "lines" || type === "brands") && (
        <Field label="Descripción"><Input value={form.description} onChange={v => set("description", v)} /></Field>
      )}
      <Field label="Estado"><Toggle checked={form.active !== false} onChange={v => set("active", v)} label={form.active !== false ? "Activo" : "Inactivo"} /></Field>
      <div className="flex gap-3 justify-end pt-2">
        <Btn variant="secondary" onClick={onClose}>Cancelar</Btn>
        <Btn onClick={handleSubmit}>{form.id ? "Guardar" : "Crear"}</Btn>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// MODULE: PRODUCTS
// ═══════════════════════════════════════════════════════════════════════
function ProductsModule({ products, setProducts, stock, lines, categories, brands, sizes, suppliers }) {
  const [search, setSearch] = useState("");
  const [filterLine, setFilterLine] = useState("");
  const [modal, setModal] = useState(null);

  const filtered = useMemo(() => {
    return products.filter(p => {
      const s = search.toLowerCase();
      const matchSearch = !s || p.name.toLowerCase().includes(s) || (p.barcode || "").includes(s);
      const matchLine = !filterLine || p.line_id === filterLine;
      return matchSearch && matchLine && p.active;
    });
  }, [products, search, filterLine]);

  function handleSave(item) {
    setProducts(prev => {
      const exists = prev.find(x => x.id === item.id);
      if (exists) return prev.map(x => x.id === item.id ? { ...x, ...item } : x);
      return [...prev, { ...item, id: uid(), active: true }];
    });
    setModal(null);
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div><h1 className="text-2xl font-bold text-gray-100">Productos</h1><p className="text-sm text-gray-500">{filtered.length} productos</p></div>
        <Btn onClick={() => setModal({})}><Plus size={16} />Nuevo Producto</Btn>
      </div>
      <div className="flex flex-wrap gap-3">
        <div className="flex-1 min-w-[200px]"><SearchInput value={search} onChange={setSearch} placeholder="Buscar por nombre o código..." /></div>
        <select value={filterLine} onChange={e => setFilterLine(e.target.value)}
          className="px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-sm text-gray-200">
          <option value="">Todas las líneas</option>
          {lines.map(l => <option key={l.id} value={l.id}>{l.name}</option>)}
        </select>
      </div>
      <div className="bg-gray-800/50 rounded-xl border border-gray-700/50 overflow-x-auto">
        <table className="w-full text-sm"><thead><tr className="text-left text-xs text-gray-500 uppercase">
          <th className="pb-3 pl-4 pt-4">Producto</th><th className="pb-3 pt-4">Línea</th><th className="pb-3 pt-4">Categoría</th><th className="pb-3 pt-4">Marca</th><th className="pb-3 pt-4">Talla</th><th className="pb-3 pt-4">P. Compra</th><th className="pb-3 pt-4">P. Venta</th><th className="pb-3 pt-4">Stock</th><th className="pb-3 pt-4 text-right pr-4">Acciones</th>
        </tr></thead><tbody>{filtered.map(p => {
          const totalQty = stock.filter(s => s.product_id === p.id).reduce((s, st) => s + st.quantity, 0);
          return (
            <tr key={p.id} className="border-t border-gray-800 hover:bg-gray-800/50">
              <td className="py-3 pl-4">
                <div className="text-gray-200 font-medium">{p.name}</div>
                <div className="text-xs text-gray-500 font-mono">{p.barcode}</div>
              </td>
              <td className="py-3 text-gray-400">{lines.find(l => l.id === p.line_id)?.name || "—"}</td>
              <td className="py-3 text-gray-400">{categories.find(c => c.id === p.category_id)?.name || "—"}</td>
              <td className="py-3 text-gray-400">{brands.find(b => b.id === p.brand_id)?.name || "—"}</td>
              <td className="py-3"><Badge color="cyan">{p.size || "—"}</Badge></td>
              <td className="py-3 text-gray-400">{fmt(p.purchase_price)}</td>
              <td className="py-3 text-amber-400 font-medium">{fmt(p.price)}</td>
              <td className="py-3"><Badge color={totalQty === 0 ? "red" : totalQty <= p.min_stock ? "amber" : "green"}>{totalQty}</Badge></td>
              <td className="py-3 pr-4 text-right space-x-1">
                <Btn size="sm" variant="ghost" onClick={() => setModal(p)}><Edit size={14} /></Btn>
              </td>
            </tr>
          );
        })}</tbody></table>
      </div>
      <Modal open={!!modal} onClose={() => setModal(null)} title={modal?.id ? "Editar Producto" : "Nuevo Producto"} wide>
        {modal && <ProductForm item={modal} lines={lines} categories={categories} brands={brands} sizes={sizes} suppliers={suppliers}
          onSave={handleSave} onClose={() => setModal(null)} />}
      </Modal>
    </div>
  );
}

function ProductForm({ item, lines, categories, brands, sizes, suppliers, onSave, onClose }) {
  const [f, setF] = useState({ barcode: "", name: "", line_id: "", category_id: "", brand_id: "", supplier_id: "", size: "", color: "", purchase_price: "", price: "", min_stock: 5, ...item });
  const set = (k, v) => setF(p => ({ ...p, [k]: v }));
  const filteredCats = categories.filter(c => !f.line_id || c.line_id === f.line_id);
  const filteredSizes = sizes.filter(s => !f.category_id || !s.category_id || s.category_id === f.category_id);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Field label="Código de Barras"><Input value={f.barcode} onChange={v => set("barcode", v)} placeholder="7501001001" /></Field>
        <Field label="Nombre" required><Input value={f.name} onChange={v => set("name", v)} placeholder="Nombre del producto" /></Field>
        <Field label="Color"><Input value={f.color} onChange={v => set("color", v)} placeholder="Color" /></Field>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Field label="Línea"><Select value={f.line_id} onChange={v => { set("line_id", v); set("category_id", ""); }} options={lines.map(l => ({ value: l.id, label: l.name }))} /></Field>
        <Field label="Categoría"><Select value={f.category_id} onChange={v => set("category_id", v)} options={filteredCats.map(c => ({ value: c.id, label: c.name }))} /></Field>
        <Field label="Marca"><Select value={f.brand_id} onChange={v => set("brand_id", v)} options={brands.map(b => ({ value: b.id, label: b.name }))} /></Field>
        <Field label="Proveedor"><Select value={f.supplier_id} onChange={v => set("supplier_id", v)} options={suppliers.map(s => ({ value: s.id, label: s.name }))} /></Field>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Field label="Talla"><Select value={f.size} onChange={v => set("size", v)} options={filteredSizes.map(s => ({ value: s.code, label: `${s.code} - ${s.name}` }))} /></Field>
        <Field label="Precio Compra"><Input type="number" value={f.purchase_price} onChange={v => set("purchase_price", v)} placeholder="0.00" /></Field>
        <Field label="Precio Venta" required><Input type="number" value={f.price} onChange={v => set("price", v)} placeholder="0.00" /></Field>
        <Field label="Stock Mínimo"><Input type="number" value={f.min_stock} onChange={v => set("min_stock", v)} /></Field>
      </div>
      <div className="flex gap-3 justify-end pt-2">
        <Btn variant="secondary" onClick={onClose}>Cancelar</Btn>
        <Btn onClick={() => { if (f.name && f.price) onSave(f); }} disabled={!f.name || !f.price}>{f.id ? "Guardar" : "Crear"}</Btn>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// MODULE: CLIENTS (with Google Maps URL parser)
// ═══════════════════════════════════════════════════════════════════════
function ClientsModule({ clients, setClients, installments, creditPlans }) {
  const [search, setSearch] = useState("");
  const [modal, setModal] = useState(null);

  const filtered = clients.filter(c => {
    const s = search.toLowerCase();
    return c.active && (!s || c.name.toLowerCase().includes(s) || (c.dni || "").includes(s));
  });

  function handleSave(item) {
    setClients(prev => {
      const exists = prev.find(x => x.id === item.id);
      if (exists) return prev.map(x => x.id === item.id ? { ...x, ...item } : x);
      return [...prev, { ...item, id: uid(), active: true, credit_used: 0 }];
    });
    setModal(null);
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div><h1 className="text-2xl font-bold text-gray-100">Clientes</h1><p className="text-sm text-gray-500">{filtered.length} clientes activos</p></div>
        <Btn onClick={() => setModal({})}><Plus size={16} />Nuevo Cliente</Btn>
      </div>
      <div className="max-w-md"><SearchInput value={search} onChange={setSearch} placeholder="Buscar por nombre o DNI..." /></div>
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filtered.map(c => {
          const plans = creditPlans.filter(p => p.client_id === c.id && p.status === "ACTIVE");
          const totalDebt = plans.reduce((s, p) => {
            const insts = installments.filter(i => i.plan_id === p.id && i.status !== "PAID");
            return s + insts.reduce((ss, i) => ss + (i.amount - i.paid_amount), 0);
          }, 0);
          const overdueCount = plans.reduce((s, p) => s + installments.filter(i => i.plan_id === p.id && i.status === "OVERDUE").length, 0);
          const available = Math.max(0, c.credit_limit - c.credit_used);

          return (
            <div key={c.id} className="bg-gray-800/80 rounded-xl border border-gray-700/50 p-5 hover:border-amber-500/30 transition-all">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-amber-500/20 rounded-full flex items-center justify-center text-amber-400 font-bold text-sm flex-shrink-0">
                  {c.name.split(" ").map(w => w[0]).slice(0, 2).join("")}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-gray-200 truncate">{c.name}</h3>
                  <p className="text-xs text-gray-500">DNI: {c.dni} | {c.phone}</p>
                </div>
                <Btn size="sm" variant="ghost" onClick={() => setModal(c)}><Edit size={14} /></Btn>
              </div>
              <div className="grid grid-cols-2 gap-3 mt-4">
                <div className="text-center p-2 bg-gray-900/50 rounded-lg">
                  <p className="text-xs text-gray-500">Límite</p>
                  <p className="text-sm font-bold text-gray-200">{fmt(c.credit_limit)}</p>
                </div>
                <div className="text-center p-2 bg-gray-900/50 rounded-lg">
                  <p className="text-xs text-gray-500">Disponible</p>
                  <p className={`text-sm font-bold ${available > 0 ? "text-emerald-400" : "text-red-400"}`}>{fmt(available)}</p>
                </div>
              </div>
              {totalDebt > 0 && (
                <div className="mt-3 flex items-center justify-between p-2 bg-red-500/5 rounded-lg border border-red-500/10">
                  <span className="text-xs text-gray-400">Deuda total</span>
                  <span className="text-sm font-bold text-red-400">{fmt(totalDebt)}</span>
                  {overdueCount > 0 && <Badge color="red">{overdueCount} vencidas</Badge>}
                </div>
              )}
              {c.lat && c.lng && (
                <div className="mt-2 flex items-center gap-1 text-xs text-gray-500">
                  <MapPin size={12} className="text-amber-500" />
                  <span>{c.lat.toFixed(4)}, {c.lng.toFixed(4)}</span>
                </div>
              )}
            </div>
          );
        })}
      </div>
      <Modal open={!!modal} onClose={() => setModal(null)} title={modal?.id ? "Editar Cliente" : "Nuevo Cliente"} wide>
        {modal && <ClientForm item={modal} onSave={handleSave} onClose={() => setModal(null)} />}
      </Modal>
    </div>
  );
}

function ClientForm({ item, onSave, onClose }) {
  const [f, setF] = useState({ dni: "", name: "", phone: "", email: "", address: "", lat: "", lng: "", credit_limit: 0, birthday: "", google_maps_url: "", ...item });
  const set = (k, v) => setF(p => ({ ...p, [k]: v }));

  function handleMapsUrl(url) {
    set("google_maps_url", url);
    const coords = parseGoogleMapsUrl(url);
    if (coords) {
      set("lat", coords.lat);
      set("lng", coords.lng);
    }
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Field label="DNI" required><Input value={f.dni} onChange={v => set("dni", v)} placeholder="12345678" /></Field>
        <Field label="Nombre Completo" required><Input value={f.name} onChange={v => set("name", v)} placeholder="Nombre Apellido" /></Field>
        <Field label="Teléfono"><Input value={f.phone} onChange={v => set("phone", v)} placeholder="987654321" /></Field>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Field label="Email"><Input value={f.email} onChange={v => set("email", v)} placeholder="email@gmail.com" /></Field>
        <Field label="Fecha de Nacimiento"><Input type="date" value={f.birthday} onChange={v => set("birthday", v)} /></Field>
        <Field label="Límite de Crédito"><Input type="number" value={f.credit_limit} onChange={v => set("credit_limit", v)} /></Field>
      </div>
      <Field label="Dirección"><Input value={f.address} onChange={v => set("address", v)} placeholder="Av. España 1520, Trujillo" /></Field>

      <div className="p-4 bg-blue-500/5 border border-blue-500/20 rounded-xl space-y-3">
        <div className="flex items-center gap-2 text-blue-400">
          <Globe size={16} /><span className="text-sm font-medium">Geolocalización vía Google Maps</span>
        </div>
        <Field label="Link de Google Maps">
          <Input value={f.google_maps_url} onChange={handleMapsUrl} placeholder="https://www.google.com/maps/@-8.1116,-79.0288,17z" />
        </Field>
        <p className="text-xs text-gray-500">Pega el enlace de Google Maps y se extraerán automáticamente la latitud y longitud.</p>
        <div className="grid grid-cols-2 gap-4">
          <Field label="Latitud">
            <Input type="number" value={f.lat} onChange={v => set("lat", v)} placeholder="-8.1116"
              className={f.lat ? "border-emerald-500/50 bg-emerald-500/5" : ""} />
          </Field>
          <Field label="Longitud">
            <Input type="number" value={f.lng} onChange={v => set("lng", v)} placeholder="-79.0288"
              className={f.lng ? "border-emerald-500/50 bg-emerald-500/5" : ""} />
          </Field>
        </div>
        {f.lat && f.lng && (
          <div className="flex items-center gap-2 text-emerald-400 text-xs">
            <CheckCircle size={14} />Coordenadas detectadas: {Number(f.lat).toFixed(6)}, {Number(f.lng).toFixed(6)}
          </div>
        )}
      </div>

      <div className="flex gap-3 justify-end pt-2">
        <Btn variant="secondary" onClick={onClose}>Cancelar</Btn>
        <Btn onClick={() => { if (f.dni && f.name) onSave(f); }} disabled={!f.dni || !f.name}>{f.id ? "Guardar" : "Crear"}</Btn>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// MODULE: POS (Point of Sale)
// ═══════════════════════════════════════════════════════════════════════
function POSModule({ products, stock, setStock, clients, sales, setSales, installments, setInstallments, creditPlans, setCreditPlans, lines, brands }) {
  const [barcode, setBarcode] = useState("");
  const [cart, setCart] = useState([]);
  const [saleType, setSaleType] = useState("CONTADO");
  const [clientId, setClientId] = useState("");
  const [numInstallments, setNumInstallments] = useState(2);
  const [discount, setDiscount] = useState(0);
  const [storeId, setStoreId] = useState("MUJERES");
  const [receipt, setReceipt] = useState(null);

  const searchResults = useMemo(() => {
    if (!barcode.trim()) return [];
    const s = barcode.toLowerCase();
    return products.filter(p => p.active && (p.barcode?.includes(s) || p.name.toLowerCase().includes(s))).slice(0, 8);
  }, [barcode, products]);

  function addToCart(product) {
    const storeStock = stock.filter(s => s.warehouse_id === storeId && s.product_id === product.id).reduce((s, st) => s + st.quantity, 0);
    setCart(prev => {
      const existing = prev.find(c => c.product_id === product.id);
      if (existing) {
        if (existing.quantity >= storeStock) return prev;
        return prev.map(c => c.product_id === product.id ? { ...c, quantity: c.quantity + 1, subtotal: (c.quantity + 1) * c.unit_price } : c);
      }
      if (storeStock <= 0) return prev;
      return [...prev, { product_id: product.id, name: product.name, unit_price: product.price, quantity: 1, subtotal: product.price, maxQty: storeStock }];
    });
    setBarcode("");
  }

  const subtotal = cart.reduce((s, c) => s + c.subtotal, 0);
  const total = Math.max(0, subtotal - discount);

  function completeSale() {
    if (cart.length === 0) return;
    if (saleType === "CREDITO" && !clientId) return;

    const saleId = uid();
    const saleNumber = `V-${String(sales.length + 1).padStart(4, "0")}`;
    const newSale = { id: saleId, sale_number: saleNumber, store_id: storeId, client_id: clientId || null, sale_type: saleType, subtotal, discount, total, payment_status: saleType === "CONTADO" ? "PAID" : "PENDING", created_at: today };
    setSales(prev => [...prev, newSale]);

    // Decrement stock
    setStock(prev => {
      let updated = [...prev];
      cart.forEach(item => {
        const idx = updated.findIndex(s => s.warehouse_id === storeId && s.product_id === item.product_id);
        if (idx >= 0) updated[idx] = { ...updated[idx], quantity: Math.max(0, updated[idx].quantity - item.quantity) };
      });
      return updated;
    });

    // Generate credit plan + installments
    if (saleType === "CREDITO" && clientId) {
      const planId = uid();
      const instAmt = +(total / numInstallments).toFixed(2);
      const newPlan = { id: planId, sale_id: saleId, client_id: clientId, total_amount: total, installments_count: numInstallments, installment_amount: instAmt, status: "ACTIVE" };
      setCreditPlans(prev => [...prev, newPlan]);

      const newInsts = [];
      for (let i = 0; i < numInstallments; i++) {
        const amt = i === numInstallments - 1 ? +(total - instAmt * (numInstallments - 1)).toFixed(2) : instAmt;
        newInsts.push({ id: uid(), plan_id: planId, installment_number: i + 1, amount: amt, due_date: daysLater(30 * (i + 1)), paid_amount: 0, status: "PENDING" });
      }
      setInstallments(prev => [...prev, ...newInsts]);
    }

    setReceipt({ ...newSale, items: cart });
    setCart([]); setDiscount(0); setClientId(""); setBarcode("");
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div><h1 className="text-2xl font-bold text-gray-100">Punto de Venta</h1></div>
        <div className="flex gap-2 items-center">
          <span className="text-xs text-gray-500">Tienda:</span>
          <select value={storeId} onChange={e => setStoreId(e.target.value)} className="px-3 py-1.5 bg-gray-800 border border-gray-700 rounded-lg text-sm text-gray-200">
            <option value="MUJERES">Tienda Mujeres</option>
            <option value="HOMBRES">Tienda Hombres</option>
          </select>
        </div>
      </div>
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Product Search */}
        <div className="lg:col-span-2 space-y-4">
          <div className="relative">
            <SearchInput value={barcode} onChange={setBarcode} placeholder="Escanear código o buscar producto..." />
            {searchResults.length > 0 && (
              <div className="absolute z-20 top-full mt-1 w-full bg-gray-800 border border-gray-700 rounded-xl shadow-2xl overflow-hidden">
                {searchResults.map(p => {
                  const qty = stock.filter(s => s.warehouse_id === storeId && s.product_id === p.id).reduce((s, st) => s + st.quantity, 0);
                  return (
                    <button key={p.id} onClick={() => addToCart(p)} disabled={qty <= 0}
                      className="w-full flex items-center justify-between px-4 py-3 hover:bg-gray-700/50 text-left border-b border-gray-800 last:border-0 disabled:opacity-40">
                      <div><p className="text-sm text-gray-200">{p.name}</p><p className="text-xs text-gray-500">{p.barcode} · {p.size} · {p.color}</p></div>
                      <div className="text-right"><p className="text-sm font-bold text-amber-400">{fmt(p.price)}</p><p className="text-xs text-gray-500">Stock: {qty}</p></div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Cart */}
          <div className="bg-gray-800/50 rounded-xl border border-gray-700/50">
            {cart.length === 0 ? <EmptyState icon={ShoppingCart} title="Carrito vacío" sub="Busca productos para agregar" /> : (
              <table className="w-full text-sm">
                <thead><tr className="text-left text-xs text-gray-500 uppercase">
                  <th className="pb-3 pl-4 pt-4">Producto</th><th className="pb-3 pt-4 text-center">Cantidad</th><th className="pb-3 pt-4">P. Unit.</th><th className="pb-3 pt-4">Subtotal</th><th className="pb-3 pt-4 pr-4"></th>
                </tr></thead>
                <tbody>{cart.map((c, idx) => (
                  <tr key={c.product_id} className="border-t border-gray-800">
                    <td className="py-3 pl-4 text-gray-200">{c.name}</td>
                    <td className="py-3 text-center">
                      <div className="inline-flex items-center gap-1">
                        <button onClick={() => setCart(p => p.map((x, i) => i === idx ? { ...x, quantity: Math.max(1, x.quantity - 1), subtotal: Math.max(1, x.quantity - 1) * x.unit_price } : x))}
                          className="w-7 h-7 rounded bg-gray-700 text-gray-300 hover:bg-gray-600 flex items-center justify-center">−</button>
                        <span className="w-8 text-center text-gray-200">{c.quantity}</span>
                        <button onClick={() => setCart(p => p.map((x, i) => i === idx ? { ...x, quantity: Math.min(x.maxQty, x.quantity + 1), subtotal: Math.min(x.maxQty, x.quantity + 1) * x.unit_price } : x))}
                          className="w-7 h-7 rounded bg-gray-700 text-gray-300 hover:bg-gray-600 flex items-center justify-center">+</button>
                      </div>
                    </td>
                    <td className="py-3 text-gray-400">{fmt(c.unit_price)}</td>
                    <td className="py-3 text-amber-400 font-medium">{fmt(c.subtotal)}</td>
                    <td className="py-3 pr-4"><Btn size="sm" variant="ghost" onClick={() => setCart(p => p.filter((_, i) => i !== idx))}><Trash2 size={14} /></Btn></td>
                  </tr>
                ))}</tbody>
              </table>
            )}
          </div>
        </div>

        {/* Sale Summary */}
        <div className="bg-gray-800/80 rounded-xl border border-gray-700/50 p-5 space-y-4 h-fit sticky top-4">
          <h3 className="font-semibold text-gray-200">Resumen de Venta</h3>
          <div className="flex gap-2">
            <button onClick={() => setSaleType("CONTADO")} className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${saleType === "CONTADO" ? "bg-emerald-500 text-white" : "bg-gray-700 text-gray-400"}`}>Contado</button>
            <button onClick={() => setSaleType("CREDITO")} className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${saleType === "CREDITO" ? "bg-purple-500 text-white" : "bg-gray-700 text-gray-400"}`}>Crédito</button>
          </div>
          {saleType === "CREDITO" && (
            <div className="space-y-3 p-3 bg-purple-500/5 border border-purple-500/20 rounded-lg">
              <Field label="Cliente">
                <Select value={clientId} onChange={setClientId} options={clients.filter(c => c.active).map(c => ({ value: c.id, label: `${c.name} (${c.dni})` }))} placeholder="Seleccionar cliente..." />
              </Field>
              <Field label="Cuotas">
                <Select value={numInstallments} onChange={v => setNumInstallments(Number(v))} options={[2, 3, 4, 5, 6].map(n => ({ value: n, label: `${n} cuotas` }))} />
              </Field>
              {clientId && total > 0 && <p className="text-xs text-purple-300">Cuota mensual: {fmt(total / numInstallments)}</p>}
            </div>
          )}
          <Field label="Descuento (S/)"><Input type="number" value={discount} onChange={setDiscount} /></Field>
          <div className="border-t border-gray-700 pt-4 space-y-2">
            <div className="flex justify-between text-sm text-gray-400"><span>Subtotal</span><span>{fmt(subtotal)}</span></div>
            {discount > 0 && <div className="flex justify-between text-sm text-red-400"><span>Descuento</span><span>-{fmt(discount)}</span></div>}
            <div className="flex justify-between text-lg font-bold text-amber-400"><span>TOTAL</span><span>{fmt(total)}</span></div>
          </div>
          <Btn className="w-full" size="lg" onClick={completeSale} disabled={cart.length === 0 || (saleType === "CREDITO" && !clientId)}>
            <ShoppingCart size={18} />{saleType === "CONTADO" ? "Cobrar" : "Registrar Crédito"}
          </Btn>
        </div>
      </div>

      {/* Receipt Modal */}
      <Modal open={!!receipt} onClose={() => setReceipt(null)} title="✅ Venta Completada">
        {receipt && (
          <div className="space-y-4">
            <div className="text-center p-4 bg-emerald-500/10 rounded-xl border border-emerald-500/20">
              <p className="text-2xl font-bold text-emerald-400">{fmt(receipt.total)}</p>
              <p className="text-sm text-gray-400">{receipt.sale_number} · {receipt.sale_type}</p>
            </div>
            <div className="space-y-2">{receipt.items.map(i => (
              <div key={i.product_id} className="flex justify-between text-sm"><span className="text-gray-300">{i.quantity}x {i.name}</span><span className="text-gray-400">{fmt(i.subtotal)}</span></div>
            ))}</div>
            <Btn className="w-full" variant="secondary" onClick={() => setReceipt(null)}>Cerrar</Btn>
          </div>
        )}
      </Modal>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// MODULE: INVENTORY MANAGEMENT
// ═══════════════════════════════════════════════════════════════════════
function InventoryModule({ stock, setStock, movements, setMovements, products, stores }) {
  const [tab, setTab] = useState("stock");
  const [storeFilter, setStoreFilter] = useState("");
  const [search, setSearch] = useState("");
  const [modal, setModal] = useState(null);

  const tabs = [
    { key: "stock", label: "Stock Actual" },
    { key: "movements", label: "Movimientos" },
    { key: "transfer", label: "Transferencias" },
  ];

  const filteredStock = useMemo(() => {
    return stock.filter(s => {
      const p = products.find(pr => pr.id === s.product_id);
      if (!p) return false;
      const matchStore = !storeFilter || s.warehouse_id === storeFilter;
      const matchSearch = !search || p.name.toLowerCase().includes(search.toLowerCase()) || (p.barcode || "").includes(search);
      return matchStore && matchSearch;
    });
  }, [stock, storeFilter, search, products]);

  function handleMovement(data) {
    const { warehouse_id, product_id, type, quantity, reason } = data;
    const qty = parseInt(quantity) || 0;
    if (qty <= 0) return;

    // Update stock
    setStock(prev => {
      const idx = prev.findIndex(s => s.warehouse_id === warehouse_id && s.product_id === product_id);
      const change = type === "ENTRADA" ? qty : type === "SALIDA" ? -qty : (type === "AJUSTE" ? qty : 0);
      if (idx >= 0) {
        const newQty = Math.max(0, prev[idx].quantity + change);
        return prev.map((s, i) => i === idx ? { ...s, quantity: newQty } : s);
      }
      if (change > 0) return [...prev, { id: uid(), warehouse_id, product_id, quantity: change }];
      return prev;
    });

    setMovements(prev => [...prev, { id: uid(), warehouse_id, product_id, type, quantity: qty, reason, created_at: today }]);
    setModal(null);
  }

  function handleTransfer(data) {
    const { from_warehouse, to_warehouse, product_id, quantity } = data;
    const qty = parseInt(quantity) || 0;
    if (qty <= 0 || from_warehouse === to_warehouse) return;

    // Decrease from source
    setStock(prev => {
      let updated = [...prev];
      const fromIdx = updated.findIndex(s => s.warehouse_id === from_warehouse && s.product_id === product_id);
      if (fromIdx >= 0) updated[fromIdx] = { ...updated[fromIdx], quantity: Math.max(0, updated[fromIdx].quantity - qty) };

      const toIdx = updated.findIndex(s => s.warehouse_id === to_warehouse && s.product_id === product_id);
      if (toIdx >= 0) updated[toIdx] = { ...updated[toIdx], quantity: updated[toIdx].quantity + qty };
      else updated.push({ id: uid(), warehouse_id: to_warehouse, product_id, quantity: qty });

      return updated;
    });

    setMovements(prev => [
      ...prev,
      { id: uid(), warehouse_id: from_warehouse, product_id, type: "TRANSFERENCIA_OUT", quantity: qty, reason: `Transferencia a ${to_warehouse}`, created_at: today },
      { id: uid(), warehouse_id: to_warehouse, product_id, type: "TRANSFERENCIA_IN", quantity: qty, reason: `Transferencia desde ${from_warehouse}`, created_at: today },
    ]);
    setModal(null);
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div><h1 className="text-2xl font-bold text-gray-100">Inventario</h1><p className="text-sm text-gray-500">Control de stock y movimientos</p></div>
        <div className="flex gap-2">
          {tab === "stock" && <Btn onClick={() => setModal("movement")}><ArrowDown size={16} />Registrar Movimiento</Btn>}
          {tab === "transfer" && <Btn onClick={() => setModal("transfer")}><ArrowRightLeft size={16} />Nueva Transferencia</Btn>}
        </div>
      </div>
      <TabBar tabs={tabs} active={tab} onChange={setTab} />
      <div className="flex flex-wrap gap-3">
        <div className="flex-1 min-w-[200px]"><SearchInput value={search} onChange={setSearch} placeholder="Buscar producto..." /></div>
        <select value={storeFilter} onChange={e => setStoreFilter(e.target.value)} className="px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-sm text-gray-200">
          <option value="">Todos los almacenes</option>
          {stores.map(s => <option key={s.code} value={s.code}>{s.name}</option>)}
        </select>
      </div>

      {tab === "stock" && (
        <div className="bg-gray-800/50 rounded-xl border border-gray-700/50 overflow-x-auto">
          <table className="w-full text-sm"><thead><tr className="text-left text-xs text-gray-500 uppercase">
            <th className="pb-3 pl-4 pt-4">Producto</th><th className="pb-3 pt-4">Almacén</th><th className="pb-3 pt-4">Cantidad</th><th className="pb-3 pt-4">Estado</th>
          </tr></thead><tbody>{filteredStock.map(s => {
            const p = products.find(pr => pr.id === s.product_id);
            if (!p) return null;
            return (
              <tr key={s.id} className="border-t border-gray-800 hover:bg-gray-800/50">
                <td className="py-3 pl-4"><div className="text-gray-200">{p.name}</div><div className="text-xs text-gray-500">{p.barcode}</div></td>
                <td className="py-3"><Badge color={s.warehouse_id === "MUJERES" ? "pink" : "blue"}>{s.warehouse_id}</Badge></td>
                <td className="py-3 text-gray-200 font-medium">{s.quantity}</td>
                <td className="py-3"><Badge color={s.quantity === 0 ? "red" : s.quantity <= (p.min_stock || 5) ? "amber" : "green"}>
                  {s.quantity === 0 ? "Sin Stock" : s.quantity <= (p.min_stock || 5) ? "Bajo" : "OK"}
                </Badge></td>
              </tr>
            );
          })}</tbody></table>
        </div>
      )}

      {tab === "movements" && (
        <div className="bg-gray-800/50 rounded-xl border border-gray-700/50 overflow-x-auto">
          <table className="w-full text-sm"><thead><tr className="text-left text-xs text-gray-500 uppercase">
            <th className="pb-3 pl-4 pt-4">Fecha</th><th className="pb-3 pt-4">Producto</th><th className="pb-3 pt-4">Almacén</th><th className="pb-3 pt-4">Tipo</th><th className="pb-3 pt-4">Cantidad</th><th className="pb-3 pt-4">Motivo</th>
          </tr></thead><tbody>{movements.sort((a, b) => b.created_at.localeCompare(a.created_at)).map(m => {
            const p = products.find(pr => pr.id === m.product_id);
            const typeColors = { ENTRADA: "green", SALIDA: "red", AJUSTE: "amber", TRANSFERENCIA_IN: "blue", TRANSFERENCIA_OUT: "purple" };
            return (
              <tr key={m.id} className="border-t border-gray-800 hover:bg-gray-800/50">
                <td className="py-3 pl-4 text-gray-400">{fmtDate(m.created_at)}</td>
                <td className="py-3 text-gray-200">{p?.name || "—"}</td>
                <td className="py-3"><Badge color={m.warehouse_id === "MUJERES" ? "pink" : "blue"}>{m.warehouse_id}</Badge></td>
                <td className="py-3"><Badge color={typeColors[m.type] || "gray"}>{m.type}</Badge></td>
                <td className="py-3 text-gray-200 font-medium">{m.quantity}</td>
                <td className="py-3 text-gray-400 text-xs">{m.reason}</td>
              </tr>
            );
          })}</tbody></table>
        </div>
      )}

      {tab === "transfer" && (
        <div className="bg-gray-800/50 rounded-xl border border-gray-700/50 overflow-x-auto">
          <table className="w-full text-sm"><thead><tr className="text-left text-xs text-gray-500 uppercase">
            <th className="pb-3 pl-4 pt-4">Fecha</th><th className="pb-3 pt-4">Producto</th><th className="pb-3 pt-4">Origen → Destino</th><th className="pb-3 pt-4">Cantidad</th>
          </tr></thead><tbody>{movements.filter(m => m.type === "TRANSFERENCIA_OUT").sort((a, b) => b.created_at.localeCompare(a.created_at)).map(m => {
            const p = products.find(pr => pr.id === m.product_id);
            return (
              <tr key={m.id} className="border-t border-gray-800 hover:bg-gray-800/50">
                <td className="py-3 pl-4 text-gray-400">{fmtDate(m.created_at)}</td>
                <td className="py-3 text-gray-200">{p?.name || "—"}</td>
                <td className="py-3"><Badge color="pink">{m.warehouse_id}</Badge> <span className="text-gray-500 mx-1">→</span> <Badge color="blue">{m.reason.replace("Transferencia a ", "")}</Badge></td>
                <td className="py-3 text-gray-200 font-medium">{m.quantity}</td>
              </tr>
            );
          })}</tbody></table>
          {movements.filter(m => m.type === "TRANSFERENCIA_OUT").length === 0 && <EmptyState icon={ArrowRightLeft} title="Sin transferencias" />}
        </div>
      )}

      {/* Movement Modal */}
      <Modal open={modal === "movement"} onClose={() => setModal(null)} title="Registrar Movimiento">
        <MovementForm products={products} stores={stores} onSave={handleMovement} onClose={() => setModal(null)} />
      </Modal>
      <Modal open={modal === "transfer"} onClose={() => setModal(null)} title="Nueva Transferencia">
        <TransferForm products={products} stores={stores} stock={stock} onSave={handleTransfer} onClose={() => setModal(null)} />
      </Modal>
    </div>
  );
}

function MovementForm({ products, stores, onSave, onClose }) {
  const [f, setF] = useState({ warehouse_id: stores[0]?.code || "MUJERES", product_id: "", type: "ENTRADA", quantity: "", reason: "" });
  const set = (k, v) => setF(p => ({ ...p, [k]: v }));
  return (
    <div className="space-y-4">
      <Field label="Almacén"><Select value={f.warehouse_id} onChange={v => set("warehouse_id", v)} options={stores.map(s => ({ value: s.code, label: s.name }))} /></Field>
      <Field label="Producto"><Select value={f.product_id} onChange={v => set("product_id", v)} options={products.filter(p => p.active).map(p => ({ value: p.id, label: `${p.name} (${p.barcode || "—"})` }))} /></Field>
      <Field label="Tipo de Movimiento"><Select value={f.type} onChange={v => set("type", v)} options={[{ value: "ENTRADA", label: "Entrada" }, { value: "SALIDA", label: "Salida" }, { value: "AJUSTE", label: "Ajuste" }]} /></Field>
      <Field label="Cantidad"><Input type="number" value={f.quantity} onChange={v => set("quantity", v)} /></Field>
      <Field label="Motivo"><Input value={f.reason} onChange={v => set("reason", v)} placeholder="Razón del movimiento" /></Field>
      <div className="flex gap-3 justify-end pt-2">
        <Btn variant="secondary" onClick={onClose}>Cancelar</Btn>
        <Btn onClick={() => onSave(f)} disabled={!f.product_id || !f.quantity}>Registrar</Btn>
      </div>
    </div>
  );
}

function TransferForm({ products, stores, stock, onSave, onClose }) {
  const [f, setF] = useState({ from_warehouse: stores[0]?.code || "MUJERES", to_warehouse: stores[1]?.code || "HOMBRES", product_id: "", quantity: "" });
  const set = (k, v) => setF(p => ({ ...p, [k]: v }));
  const available = stock.find(s => s.warehouse_id === f.from_warehouse && s.product_id === f.product_id)?.quantity || 0;
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <Field label="Almacén Origen"><Select value={f.from_warehouse} onChange={v => set("from_warehouse", v)} options={stores.map(s => ({ value: s.code, label: s.name }))} /></Field>
        <Field label="Almacén Destino"><Select value={f.to_warehouse} onChange={v => set("to_warehouse", v)} options={stores.map(s => ({ value: s.code, label: s.name }))} /></Field>
      </div>
      <Field label="Producto"><Select value={f.product_id} onChange={v => set("product_id", v)} options={products.filter(p => p.active).map(p => ({ value: p.id, label: `${p.name} (${p.barcode || "—"})` }))} /></Field>
      {f.product_id && <p className="text-xs text-gray-400">Stock disponible en origen: <span className="text-amber-400 font-medium">{available} uds.</span></p>}
      <Field label="Cantidad"><Input type="number" value={f.quantity} onChange={v => set("quantity", v)} /></Field>
      <div className="flex gap-3 justify-end pt-2">
        <Btn variant="secondary" onClick={onClose}>Cancelar</Btn>
        <Btn onClick={() => onSave(f)} disabled={!f.product_id || !f.quantity || f.from_warehouse === f.to_warehouse}>Transferir</Btn>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// MODULE: STORES MANAGEMENT
// ═══════════════════════════════════════════════════════════════════════
function StoresModule({ stores, setStores, stock, products }) {
  const [modal, setModal] = useState(null);

  function handleSave(item) {
    setStores(prev => {
      const exists = prev.find(x => x.id === item.id);
      if (exists) return prev.map(x => x.id === item.id ? { ...x, ...item } : x);
      return [...prev, { ...item, id: uid(), active: true }];
    });
    setModal(null);
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold text-gray-100">Tiendas / Almacenes</h1><p className="text-sm text-gray-500">Gestión de puntos de venta</p></div>
        <Btn onClick={() => setModal({})}><Plus size={16} />Nueva Tienda</Btn>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {stores.map(s => {
          const storeStock = stock.filter(st => st.warehouse_id === s.code);
          const totalUnits = storeStock.reduce((sum, st) => sum + st.quantity, 0);
          const totalValue = storeStock.reduce((sum, st) => {
            const p = products.find(pr => pr.id === st.product_id);
            return sum + (p ? st.quantity * p.price : 0);
          }, 0);
          const uniqueProducts = storeStock.filter(st => st.quantity > 0).length;

          return (
            <div key={s.id} className="bg-gray-800/80 rounded-xl border border-gray-700/50 p-6 hover:border-amber-500/30 transition-all">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-amber-500/15 rounded-xl"><Building2 size={24} className="text-amber-400" /></div>
                  <div>
                    <h3 className="font-bold text-gray-200">{s.name}</h3>
                    <p className="text-xs text-gray-500 font-mono">{s.code}</p>
                  </div>
                </div>
                <Btn size="sm" variant="ghost" onClick={() => setModal(s)}><Edit size={14} /></Btn>
              </div>
              <p className="text-sm text-gray-400 mt-3">{s.address}</p>
              {s.phone && <p className="text-xs text-gray-500 mt-1 flex items-center gap-1"><Phone size={12} />{s.phone}</p>}
              <div className="grid grid-cols-3 gap-3 mt-4">
                <div className="text-center p-2 bg-gray-900/50 rounded-lg"><p className="text-xs text-gray-500">Productos</p><p className="text-lg font-bold text-gray-200">{uniqueProducts}</p></div>
                <div className="text-center p-2 bg-gray-900/50 rounded-lg"><p className="text-xs text-gray-500">Unidades</p><p className="text-lg font-bold text-amber-400">{totalUnits}</p></div>
                <div className="text-center p-2 bg-gray-900/50 rounded-lg"><p className="text-xs text-gray-500">Valor</p><p className="text-lg font-bold text-emerald-400">{fmt(totalValue)}</p></div>
              </div>
              <Badge color={s.active ? "green" : "gray"} className="mt-3">{s.active ? "Activa" : "Inactiva"}</Badge>
            </div>
          );
        })}
      </div>
      <Modal open={!!modal} onClose={() => setModal(null)} title={modal?.id ? "Editar Tienda" : "Nueva Tienda"}>
        {modal && (
          <div className="space-y-4">
            <StoreForm item={modal} onSave={handleSave} onClose={() => setModal(null)} />
          </div>
        )}
      </Modal>
    </div>
  );
}

function StoreForm({ item, onSave, onClose }) {
  const [f, setF] = useState({ code: "", name: "", address: "", phone: "", active: true, ...item });
  const set = (k, v) => setF(p => ({ ...p, [k]: v }));
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <Field label="Código" required><Input value={f.code} onChange={v => set("code", v.toUpperCase())} placeholder="MUJERES" /></Field>
        <Field label="Nombre" required><Input value={f.name} onChange={v => set("name", v)} placeholder="Tienda Mujeres" /></Field>
      </div>
      <Field label="Dirección"><Input value={f.address} onChange={v => set("address", v)} /></Field>
      <Field label="Teléfono"><Input value={f.phone} onChange={v => set("phone", v)} /></Field>
      <Field label="Estado"><Toggle checked={f.active} onChange={v => set("active", v)} label={f.active ? "Activa" : "Inactiva"} /></Field>
      <div className="flex gap-3 justify-end pt-2">
        <Btn variant="secondary" onClick={onClose}>Cancelar</Btn>
        <Btn onClick={() => { if (f.code && f.name) onSave(f); }}>{f.id ? "Guardar" : "Crear"}</Btn>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// MODULE: COLLECTIONS (Cobranzas)
// ═══════════════════════════════════════════════════════════════════════
function CollectionsModule({ clients, installments, setInstallments, creditPlans, collectionActions, setCollectionActions }) {
  const [tab, setTab] = useState("overdue");
  const [payModal, setPayModal] = useState(null);
  const [actionModal, setActionModal] = useState(null);

  const clientDebt = useMemo(() => {
    return clients.filter(c => c.active).map(c => {
      const plans = creditPlans.filter(p => p.client_id === c.id && p.status === "ACTIVE");
      const insts = installments.filter(i => plans.some(p => p.id === i.plan_id));
      const overdue = insts.filter(i => i.status === "OVERDUE");
      const pending = insts.filter(i => i.status === "PENDING" || i.status === "PARTIAL");
      const paid = insts.filter(i => i.status === "PAID");
      const overdueAmt = overdue.reduce((s, i) => s + (i.amount - i.paid_amount), 0);
      const pendingAmt = pending.reduce((s, i) => s + (i.amount - i.paid_amount), 0);
      return { ...c, overdue, pending, paid, overdueAmt, pendingAmt, totalDebt: overdueAmt + pendingAmt };
    }).filter(c => c.totalDebt > 0).sort((a, b) => b.overdueAmt - a.overdueAmt);
  }, [clients, installments, creditPlans]);

  const overdueInst = installments.filter(i => i.status === "OVERDUE");
  const pendingInst = installments.filter(i => i.status === "PENDING" || i.status === "PARTIAL");
  const paidInst = installments.filter(i => i.status === "PAID");

  const tabs = [
    { key: "overdue", label: "Vencidas", count: overdueInst.length },
    { key: "pending", label: "Pendientes", count: pendingInst.length },
    { key: "paid", label: "Pagadas", count: paidInst.length },
    { key: "actions", label: "Acciones" },
  ];

  function applyPayment(clientId, amount) {
    if (!amount || amount <= 0) return;
    let remaining = amount;
    const plans = creditPlans.filter(p => p.client_id === clientId && p.status === "ACTIVE");

    setInstallments(prev => {
      let updated = [...prev];
      // oldest_due_first: overdue first, then upcoming
      const clientInsts = updated.filter(i => plans.some(p => p.id === i.plan_id) && i.status !== "PAID")
        .sort((a, b) => {
          const aOverdue = a.status === "OVERDUE" ? 0 : 1;
          const bOverdue = b.status === "OVERDUE" ? 0 : 1;
          if (aOverdue !== bOverdue) return aOverdue - bOverdue;
          return a.due_date.localeCompare(b.due_date);
        });

      for (const inst of clientInsts) {
        if (remaining <= 0) break;
        const owed = inst.amount - inst.paid_amount;
        const pay = Math.min(remaining, owed);
        const newPaid = inst.paid_amount + pay;
        const newStatus = newPaid >= inst.amount ? "PAID" : "PARTIAL";
        updated = updated.map(i => i.id === inst.id ? { ...i, paid_amount: +newPaid.toFixed(2), status: newStatus, paid_at: newStatus === "PAID" ? today : undefined } : i);
        remaining -= pay;
      }
      return updated;
    });
    setPayModal(null);
  }

  function addAction(data) {
    setCollectionActions(prev => [...prev, { ...data, id: uid(), created_at: today }]);
    setActionModal(null);
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div><h1 className="text-2xl font-bold text-gray-100">Cobranzas</h1></div>
        <div className="flex gap-2">
          <Btn variant="secondary" onClick={() => setActionModal({})}><Phone size={16} />Registrar Acción</Btn>
        </div>
      </div>
      <TabBar tabs={tabs} active={tab} onChange={setTab} />

      {/* Client debt summary */}
      {(tab === "overdue" || tab === "pending") && (
        <div className="space-y-4">
          {clientDebt.map(c => (
            <div key={c.id} className="bg-gray-800/80 rounded-xl border border-gray-700/50 p-5">
              <div className="flex items-center justify-between flex-wrap gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-red-500/20 rounded-full flex items-center justify-center text-red-400 font-bold text-sm">
                    {c.name.split(" ").map(w => w[0]).slice(0, 2).join("")}
                  </div>
                  <div><h3 className="font-semibold text-gray-200">{c.name}</h3><p className="text-xs text-gray-500">{c.phone} · {c.dni}</p></div>
                </div>
                <div className="flex gap-3 items-center">
                  {c.overdueAmt > 0 && <Badge color="red">Vencido: {fmt(c.overdueAmt)}</Badge>}
                  <Badge color="amber">Total: {fmt(c.totalDebt)}</Badge>
                  <Btn size="sm" onClick={() => setPayModal(c)}><DollarSign size={14} />Cobrar</Btn>
                </div>
              </div>
              <div className="mt-3 space-y-2">
                {(tab === "overdue" ? c.overdue : c.pending).map(i => (
                  <div key={i.id} className="flex items-center justify-between p-2 bg-gray-900/50 rounded-lg text-sm">
                    <div><span className="text-gray-400">Cuota #{i.installment_number}</span><span className="text-gray-500 ml-2">{fmtDate(i.due_date)}</span></div>
                    <div className="flex items-center gap-3">
                      {i.paid_amount > 0 && <span className="text-xs text-emerald-400">Pagado: {fmt(i.paid_amount)}</span>}
                      <span className="font-medium text-gray-200">{fmt(i.amount - i.paid_amount)}</span>
                      {i.status === "OVERDUE" && <Badge color="red">{diffDays(i.due_date)}d</Badge>}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
          {clientDebt.length === 0 && <EmptyState icon={CheckCircle} title="Sin deudas" sub="Todos los créditos están al día" />}
        </div>
      )}

      {tab === "paid" && (
        <div className="bg-gray-800/50 rounded-xl border border-gray-700/50 overflow-x-auto">
          <table className="w-full text-sm"><thead><tr className="text-left text-xs text-gray-500 uppercase">
            <th className="pb-3 pl-4 pt-4">Cuota</th><th className="pb-3 pt-4">Monto</th><th className="pb-3 pt-4">Pagado</th><th className="pb-3 pt-4">Fecha Pago</th>
          </tr></thead><tbody>{paidInst.map(i => (
            <tr key={i.id} className="border-t border-gray-800"><td className="py-3 pl-4 text-gray-200">#{i.installment_number}</td><td className="py-3 text-gray-400">{fmt(i.amount)}</td><td className="py-3 text-emerald-400">{fmt(i.paid_amount)}</td><td className="py-3 text-gray-400">{fmtDate(i.paid_at)}</td></tr>
          ))}</tbody></table>
        </div>
      )}

      {tab === "actions" && (
        <div className="space-y-3">
          {collectionActions.sort((a, b) => b.created_at.localeCompare(a.created_at)).map(a => {
            const typeIcons = { LLAMADA: "📞", VISITA: "🏠", WHATSAPP: "💬", MOTORIZADO: "🏍️", EMAIL: "📧" };
            const resultColors = { PROMESA_PAGO: "amber", PAGO: "green", NO_RESPONDE: "gray", SIN_INTENCION: "red", REPROGRAMADO: "blue" };
            return (
              <div key={a.id} className="bg-gray-800/80 rounded-xl border border-gray-700/50 p-4 flex items-center gap-4">
                <span className="text-2xl">{typeIcons[a.action_type] || "📋"}</span>
                <div className="flex-1">
                  <div className="flex items-center gap-2"><span className="font-medium text-gray-200">{a.client_name}</span><Badge color={resultColors[a.result] || "gray"}>{a.result}</Badge></div>
                  {a.notes && <p className="text-xs text-gray-400 mt-1">{a.notes}</p>}
                  {a.payment_promise_date && <p className="text-xs text-amber-400 mt-1">Promesa: {fmtDate(a.payment_promise_date)}</p>}
                </div>
                <span className="text-xs text-gray-500">{fmtDate(a.created_at)}</span>
              </div>
            );
          })}
          {collectionActions.length === 0 && <EmptyState icon={Phone} title="Sin acciones registradas" />}
        </div>
      )}

      {/* Payment Modal */}
      <Modal open={!!payModal} onClose={() => setPayModal(null)} title={`Cobrar a ${payModal?.name || ""}`}>
        {payModal && <PaymentForm client={payModal} onPay={amt => applyPayment(payModal.id, amt)} onClose={() => setPayModal(null)} />}
      </Modal>

      {/* Action Modal */}
      <Modal open={!!actionModal} onClose={() => setActionModal(null)} title="Registrar Acción de Cobranza">
        {actionModal && <ActionForm clients={clients} onSave={addAction} onClose={() => setActionModal(null)} />}
      </Modal>
    </div>
  );
}

function PaymentForm({ client, onPay, onClose }) {
  const [amount, setAmount] = useState("");
  return (
    <div className="space-y-4">
      <div className="p-4 bg-gray-800 rounded-lg"><p className="text-sm text-gray-400">Deuda total: <span className="text-red-400 font-bold">{fmt(client.totalDebt)}</span></p></div>
      <Field label="Monto a cobrar"><Input type="number" value={amount} onChange={setAmount} placeholder="0.00" /></Field>
      <p className="text-xs text-gray-500">El pago se aplicará automáticamente a las cuotas más antiguas primero (oldest_due_first).</p>
      <div className="flex gap-3 justify-end">
        <Btn variant="secondary" onClick={onClose}>Cancelar</Btn>
        <Btn onClick={() => onPay(Number(amount))} disabled={!amount || Number(amount) <= 0}>Registrar Pago</Btn>
      </div>
    </div>
  );
}

function ActionForm({ clients, onSave, onClose }) {
  const [f, setF] = useState({ client_id: "", client_name: "", action_type: "LLAMADA", result: "NO_RESPONDE", payment_promise_date: "", notes: "" });
  const set = (k, v) => setF(p => ({ ...p, [k]: v }));
  return (
    <div className="space-y-4">
      <Field label="Cliente"><Select value={f.client_id} onChange={v => { set("client_id", v); set("client_name", clients.find(c => c.id === v)?.name || ""); }}
        options={clients.filter(c => c.active).map(c => ({ value: c.id, label: c.name }))} /></Field>
      <div className="grid grid-cols-2 gap-4">
        <Field label="Tipo"><Select value={f.action_type} onChange={v => set("action_type", v)}
          options={["LLAMADA", "VISITA", "WHATSAPP", "MOTORIZADO", "EMAIL", "OTRO"].map(v => ({ value: v, label: v }))} /></Field>
        <Field label="Resultado"><Select value={f.result} onChange={v => set("result", v)}
          options={["PROMESA_PAGO", "SIN_INTENCION", "NO_RESPONDE", "PAGO", "REPROGRAMADO", "OTRO"].map(v => ({ value: v, label: v }))} /></Field>
      </div>
      {f.result === "PROMESA_PAGO" && <Field label="Fecha Promesa de Pago"><Input type="date" value={f.payment_promise_date} onChange={v => set("payment_promise_date", v)} /></Field>}
      <Field label="Notas"><Input value={f.notes} onChange={v => set("notes", v)} placeholder="Observaciones..." /></Field>
      <div className="flex gap-3 justify-end"><Btn variant="secondary" onClick={onClose}>Cancelar</Btn><Btn onClick={() => { if (f.client_id) onSave(f); }}>Guardar</Btn></div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// MODULE: DEBT MAP (Mapa de Deudores)
// ═══════════════════════════════════════════════════════════════════════
function DebtMapModule({ clients, installments, creditPlans }) {
  const [filter, setFilter] = useState("all"); // all, overdue, upcoming
  const mapRef = useRef(null);
  const mapInstance = useRef(null);
  const markersRef = useRef([]);

  const clientsWithDebt = useMemo(() => {
    return clients.filter(c => c.active && c.lat && c.lng).map(c => {
      const plans = creditPlans.filter(p => p.client_id === c.id && p.status === "ACTIVE");
      const insts = installments.filter(i => plans.some(p => p.id === i.plan_id) && i.status !== "PAID");
      const overdueAmt = insts.filter(i => i.status === "OVERDUE").reduce((s, i) => s + (i.amount - i.paid_amount), 0);
      const pendingAmt = insts.filter(i => i.status !== "OVERDUE").reduce((s, i) => s + (i.amount - i.paid_amount), 0);
      const totalDebt = overdueAmt + pendingAmt;
      return { ...c, overdueAmt, pendingAmt, totalDebt, hasOverdue: overdueAmt > 0 };
    }).filter(c => {
      if (filter === "overdue") return c.hasOverdue;
      if (filter === "upcoming") return c.totalDebt > 0 && !c.hasOverdue;
      return c.totalDebt > 0;
    });
  }, [clients, installments, creditPlans, filter]);

  useEffect(() => {
    if (!mapRef.current || mapInstance.current) return;

    // Load Leaflet CSS
    if (!document.getElementById("leaflet-css")) {
      const link = document.createElement("link");
      link.id = "leaflet-css";
      link.rel = "stylesheet";
      link.href = "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css";
      document.head.appendChild(link);
    }

    // Load Leaflet JS
    if (!window.L) {
      const script = document.createElement("script");
      script.src = "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js";
      script.onload = () => initMap();
      document.head.appendChild(script);
    } else {
      initMap();
    }

    function initMap() {
      const map = window.L.map(mapRef.current).setView([-8.1116, -79.0288], 14);
      window.L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: '© OpenStreetMap'
      }).addTo(map);
      mapInstance.current = map;
      updateMarkers();
    }
  }, []);

  function updateMarkers() {
    if (!mapInstance.current || !window.L) return;

    // Clear existing markers
    markersRef.current.forEach(m => mapInstance.current.removeLayer(m));
    markersRef.current = [];

    clientsWithDebt.forEach(c => {
      const color = c.hasOverdue ? "#ef4444" : "#f59e0b";
      const icon = window.L.divIcon({
        className: "custom-marker",
        html: `<div style="width:32px;height:32px;border-radius:50%;background:${color};border:3px solid white;box-shadow:0 2px 8px rgba(0,0,0,0.4);display:flex;align-items:center;justify-content:center;color:white;font-size:11px;font-weight:bold;">${c.name.split(" ").map(w => w[0]).slice(0, 2).join("")}</div>`,
        iconSize: [32, 32],
        iconAnchor: [16, 16],
      });

      const marker = window.L.marker([c.lat, c.lng], { icon }).addTo(mapInstance.current);
      marker.bindPopup(`
        <div style="font-family:system-ui;min-width:200px;">
          <strong style="font-size:14px;">${c.name}</strong><br/>
          <span style="color:#666;font-size:12px;">${c.phone} · ${c.address}</span>
          <hr style="margin:8px 0;border-color:#eee;"/>
          ${c.hasOverdue ? `<div style="color:#ef4444;font-weight:bold;">Vencido: S/ ${c.overdueAmt.toFixed(2)}</div>` : ""}
          ${c.pendingAmt > 0 ? `<div style="color:#f59e0b;">Pendiente: S/ ${c.pendingAmt.toFixed(2)}</div>` : ""}
          <div style="font-weight:bold;margin-top:4px;">Total: S/ ${c.totalDebt.toFixed(2)}</div>
        </div>
      `);
      markersRef.current.push(marker);
    });

    // Fit bounds
    if (clientsWithDebt.length > 0) {
      const bounds = window.L.latLngBounds(clientsWithDebt.map(c => [c.lat, c.lng]));
      mapInstance.current.fitBounds(bounds.pad(0.2));
    }
  }

  useEffect(() => { updateMarkers(); }, [clientsWithDebt]);

  const totalOverdue = clientsWithDebt.reduce((s, c) => s + c.overdueAmt, 0);
  const totalPending = clientsWithDebt.reduce((s, c) => s + c.pendingAmt, 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div><h1 className="text-2xl font-bold text-gray-100">Mapa de Deudores</h1><p className="text-sm text-gray-500">Visualización geográfica de clientes con deuda</p></div>
      </div>
      <div className="grid grid-cols-3 gap-4">
        <Stat icon={MapPin} label="Deudores" value={clientsWithDebt.length} color="amber" />
        <Stat icon={AlertTriangle} label="Deuda Vencida" value={fmt(totalOverdue)} color="red" />
        <Stat icon={Clock} label="Deuda Próxima" value={fmt(totalPending)} color="blue" />
      </div>
      <div className="flex gap-2">
        {[{ key: "all", label: "Todos" }, { key: "overdue", label: "Solo Vencidos" }, { key: "upcoming", label: "Solo Próximos" }].map(f => (
          <button key={f.key} onClick={() => setFilter(f.key)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${filter === f.key ? "bg-amber-500 text-gray-900" : "bg-gray-800 text-gray-400 hover:text-gray-200"}`}>{f.label}</button>
        ))}
      </div>
      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-gray-800/80 rounded-xl border border-gray-700/50 overflow-hidden" style={{ minHeight: 500 }}>
          <div ref={mapRef} style={{ width: "100%", height: 500 }} />
        </div>
        <div className="space-y-3 max-h-[500px] overflow-y-auto">
          <h3 className="font-semibold text-gray-300 text-sm uppercase tracking-wider">Listado ({clientsWithDebt.length})</h3>
          {clientsWithDebt.map(c => (
            <div key={c.id} className="bg-gray-800/80 rounded-lg border border-gray-700/50 p-3 hover:border-amber-500/30 transition-all cursor-pointer"
              onClick={() => { if (mapInstance.current) mapInstance.current.setView([c.lat, c.lng], 16); }}>
              <div className="flex items-center gap-2">
                <div className={`w-3 h-3 rounded-full ${c.hasOverdue ? "bg-red-500" : "bg-amber-500"}`} />
                <span className="text-sm font-medium text-gray-200 truncate">{c.name}</span>
              </div>
              <div className="flex items-center justify-between mt-2">
                <span className="text-xs text-gray-500">{c.address}</span>
                <span className={`text-sm font-bold ${c.hasOverdue ? "text-red-400" : "text-amber-400"}`}>{fmt(c.totalDebt)}</span>
              </div>
              {c.google_maps_url && (
                <a href={c.google_maps_url} target="_blank" rel="noopener noreferrer" className="text-xs text-blue-400 hover:underline mt-1 flex items-center gap-1"
                  onClick={e => e.stopPropagation()}>
                  <ExternalLink size={10} />Abrir en Google Maps
                </a>
              )}
            </div>
          ))}
          {clientsWithDebt.length === 0 && <EmptyState icon={MapPin} title="Sin deudores con ubicación" />}
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// MODULE: REPORTS
// ═══════════════════════════════════════════════════════════════════════
function ReportsModule({ sales, installments, stock, products, clients, stores }) {
  const totalSales = sales.reduce((s, v) => s + v.total, 0);
  const cashSales = sales.filter(v => v.sale_type === "CONTADO").reduce((s, v) => s + v.total, 0);
  const creditSales = sales.filter(v => v.sale_type === "CREDITO").reduce((s, v) => s + v.total, 0);
  const avgTicket = sales.length ? totalSales / sales.length : 0;

  const collected = installments.filter(i => i.status === "PAID").reduce((s, i) => s + i.paid_amount, 0);
  const pending = installments.filter(i => i.status !== "PAID").reduce((s, i) => s + (i.amount - i.paid_amount), 0);
  const collectionRate = collected + pending > 0 ? (collected / (collected + pending)) * 100 : 0;

  const storeData = stores.map(s => {
    const storeSales = sales.filter(v => v.store_id === s.code);
    const storeTotal = storeSales.reduce((sum, v) => sum + v.total, 0);
    return { ...s, total: storeTotal, count: storeSales.length };
  });
  const maxStoreTotal = Math.max(...storeData.map(s => s.total), 1);

  const totalStockUnits = stock.reduce((s, st) => s + st.quantity, 0);
  const totalStockValue = stock.reduce((s, st) => {
    const p = products.find(pr => pr.id === st.product_id);
    return s + (p ? st.quantity * p.price : 0);
  }, 0);
  const totalCostValue = stock.reduce((s, st) => {
    const p = products.find(pr => pr.id === st.product_id);
    return s + (p ? st.quantity * (p.purchase_price || 0) : 0);
  }, 0);

  return (
    <div className="space-y-6">
      <div><h1 className="text-2xl font-bold text-gray-100">Reportes</h1><p className="text-sm text-gray-500">Análisis del negocio</p></div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Stat icon={DollarSign} label="Ventas Totales" value={fmt(totalSales)} color="green" />
        <Stat icon={ShoppingCart} label="Ticket Promedio" value={fmt(avgTicket)} color="amber" />
        <Stat icon={CreditCard} label="Cobrado" value={fmt(collected)} color="blue" />
        <Stat icon={Package} label="Valor Inventario" value={fmt(totalStockValue)} color="purple" />
      </div>
      <div className="grid lg:grid-cols-2 gap-6">
        <div className="bg-gray-800/80 rounded-xl border border-gray-700/50 p-5">
          <h3 className="font-semibold text-gray-200 mb-4">Ventas por Tipo</h3>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-1"><span className="text-gray-400">Contado</span><span className="text-emerald-400">{fmt(cashSales)}</span></div>
              <div className="h-3 bg-gray-700 rounded-full overflow-hidden"><div className="h-full bg-emerald-500 rounded-full" style={{ width: `${totalSales > 0 ? (cashSales / totalSales) * 100 : 0}%` }} /></div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1"><span className="text-gray-400">Crédito</span><span className="text-purple-400">{fmt(creditSales)}</span></div>
              <div className="h-3 bg-gray-700 rounded-full overflow-hidden"><div className="h-full bg-purple-500 rounded-full" style={{ width: `${totalSales > 0 ? (creditSales / totalSales) * 100 : 0}%` }} /></div>
            </div>
          </div>
        </div>
        <div className="bg-gray-800/80 rounded-xl border border-gray-700/50 p-5">
          <h3 className="font-semibold text-gray-200 mb-4">Rendimiento de Cobranza</h3>
          <div className="flex items-center gap-4">
            <div className="relative w-24 h-24">
              <svg viewBox="0 0 36 36" className="w-24 h-24 -rotate-90">
                <circle cx="18" cy="18" r="14" fill="none" stroke="#374151" strokeWidth="3" />
                <circle cx="18" cy="18" r="14" fill="none" stroke="#f59e0b" strokeWidth="3" strokeDasharray={`${collectionRate * 0.88} 88`} strokeLinecap="round" />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center"><span className="text-lg font-bold text-amber-400">{collectionRate.toFixed(0)}%</span></div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-emerald-500" /><span className="text-sm text-gray-400">Cobrado: {fmt(collected)}</span></div>
              <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-red-500" /><span className="text-sm text-gray-400">Pendiente: {fmt(pending)}</span></div>
            </div>
          </div>
        </div>
        <div className="bg-gray-800/80 rounded-xl border border-gray-700/50 p-5">
          <h3 className="font-semibold text-gray-200 mb-4">Ventas por Tienda</h3>
          <div className="space-y-4">
            {storeData.map(s => (
              <div key={s.code}>
                <div className="flex justify-between text-sm mb-1"><span className="text-gray-400">{s.name} ({s.count} ventas)</span><span className="text-amber-400">{fmt(s.total)}</span></div>
                <div className="h-3 bg-gray-700 rounded-full overflow-hidden"><div className="h-full bg-amber-500 rounded-full" style={{ width: `${(s.total / maxStoreTotal) * 100}%` }} /></div>
              </div>
            ))}
          </div>
        </div>
        <div className="bg-gray-800/80 rounded-xl border border-gray-700/50 p-5">
          <h3 className="font-semibold text-gray-200 mb-4">Inventario</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-4 bg-gray-900/50 rounded-lg"><p className="text-xs text-gray-500">Unidades</p><p className="text-2xl font-bold text-gray-200">{totalStockUnits}</p></div>
            <div className="text-center p-4 bg-gray-900/50 rounded-lg"><p className="text-xs text-gray-500">Productos</p><p className="text-2xl font-bold text-gray-200">{products.length}</p></div>
            <div className="text-center p-4 bg-gray-900/50 rounded-lg"><p className="text-xs text-gray-500">Valor Venta</p><p className="text-xl font-bold text-amber-400">{fmt(totalStockValue)}</p></div>
            <div className="text-center p-4 bg-gray-900/50 rounded-lg"><p className="text-xs text-gray-500">Valor Costo</p><p className="text-xl font-bold text-gray-400">{fmt(totalCostValue)}</p></div>
          </div>
          <div className="mt-4 p-3 bg-emerald-500/10 rounded-lg border border-emerald-500/20">
            <p className="text-sm text-emerald-400 font-medium">Margen potencial: {fmt(totalStockValue - totalCostValue)}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// MAIN APP
// ═══════════════════════════════════════════════════════════════════════
export default function App() {
  const [page, setPage] = useState("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // State
  const [stores, setStores] = useState(initStores);
  const [lines, setLines] = useState(initLines);
  const [categories, setCategories] = useState(initCategories);
  const [brands, setBrands] = useState(initBrands);
  const [sizes, setSizes] = useState(initSizes);
  const [suppliers, setSuppliers] = useState(initSuppliers);
  const [products, setProducts] = useState(initProducts);
  const [stock, setStock] = useState(initStock);
  const [movements, setMovements] = useState(initMovements);
  const [clients, setClients] = useState(initClients);
  const [sales, setSales] = useState(initSales);
  const [installments, setInstallments] = useState(initInstallments);
  const [creditPlans, setCreditPlans] = useState(initCreditPlans);
  const [collectionActions, setCollectionActions] = useState(initCollectionActions);

  // Auto-update overdue installments
  useEffect(() => {
    setInstallments(prev => prev.map(i => {
      if (i.status === "PENDING" && diffDays(i.due_date) > 0) return { ...i, status: "OVERDUE" };
      return i;
    }));
  }, []);

  const overdueCount = installments.filter(i => i.status === "OVERDUE").length;

  const navItems = [
    { key: "dashboard", icon: LayoutDashboard, label: "Dashboard" },
    { key: "pos", icon: ShoppingCart, label: "Punto de Venta" },
    { key: "products", icon: Package, label: "Productos" },
    { key: "catalogs", icon: Layers, label: "Catálogos" },
    { key: "clients", icon: Users, label: "Clientes" },
    { key: "inventory", icon: Warehouse, label: "Inventario" },
    { key: "stores", icon: Building2, label: "Tiendas" },
    { key: "collections", icon: CreditCard, label: "Cobranzas", badge: overdueCount },
    { key: "debtmap", icon: MapIcon, label: "Mapa Deudores" },
    { key: "reports", icon: BarChart3, label: "Reportes" },
  ];

  function renderPage() {
    switch (page) {
      case "dashboard": return <Dashboard sales={sales} installments={installments} stock={stock} products={products} clients={clients} />;
      case "pos": return <POSModule products={products} stock={stock} setStock={setStock} clients={clients} sales={sales} setSales={setSales}
        installments={installments} setInstallments={setInstallments} creditPlans={creditPlans} setCreditPlans={setCreditPlans} lines={lines} brands={brands} />;
      case "products": return <ProductsModule products={products} setProducts={setProducts} stock={stock} lines={lines} categories={categories} brands={brands} sizes={sizes} suppliers={suppliers} />;
      case "catalogs": return <CatalogsModule lines={lines} setLines={setLines} categories={categories} setCategories={setCategories} brands={brands} setBrands={setBrands} sizes={sizes} setSizes={setSizes} suppliers={suppliers} setSuppliers={setSuppliers} />;
      case "clients": return <ClientsModule clients={clients} setClients={setClients} installments={installments} creditPlans={creditPlans} />;
      case "inventory": return <InventoryModule stock={stock} setStock={setStock} movements={movements} setMovements={setMovements} products={products} stores={stores} />;
      case "stores": return <StoresModule stores={stores} setStores={setStores} stock={stock} products={products} />;
      case "collections": return <CollectionsModule clients={clients} installments={installments} setInstallments={setInstallments} creditPlans={creditPlans} collectionActions={collectionActions} setCollectionActions={setCollectionActions} />;
      case "debtmap": return <DebtMapModule clients={clients} installments={installments} creditPlans={creditPlans} />;
      case "reports": return <ReportsModule sales={sales} installments={installments} stock={stock} products={products} clients={clients} stores={stores} />;
      default: return null;
    }
  }

  return (
    <div className="flex h-screen bg-gray-950 text-gray-200" style={{ fontFamily: "'DM Sans', system-ui, sans-serif" }}>
      <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet" />

      {/* Sidebar */}
      <aside className={`fixed lg:static inset-y-0 left-0 z-40 w-64 bg-gray-900 border-r border-gray-800 flex flex-col transition-transform lg:translate-x-0 ${sidebarOpen ? "translate-x-0" : "-translate-x-full"}`}>
        <div className="p-5 border-b border-gray-800">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-gradient-to-br from-amber-400 to-amber-600 rounded-xl flex items-center justify-center text-gray-900 font-black text-sm">A</div>
            <div><h1 className="font-bold text-gray-100 text-sm">Adiction Boutique</h1><p className="text-[10px] text-gray-500 uppercase tracking-widest">Sistema de Gestión</p></div>
          </div>
        </div>
        <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto">
          {navItems.map(n => (
            <button key={n.key} onClick={() => { setPage(n.key); setSidebarOpen(false); }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${page === n.key ? "bg-amber-500/15 text-amber-400" : "text-gray-400 hover:text-gray-200 hover:bg-gray-800"}`}>
              <n.icon size={18} />{n.label}
              {n.badge > 0 && <span className="ml-auto px-2 py-0.5 rounded-full bg-red-500 text-white text-xs font-bold">{n.badge}</span>}
            </button>
          ))}
        </nav>
        <div className="p-4 border-t border-gray-800 text-xs text-gray-600">v2.0 — React Demo</div>
      </aside>

      {/* Overlay */}
      {sidebarOpen && <div className="fixed inset-0 z-30 bg-black/50 lg:hidden" onClick={() => setSidebarOpen(false)} />}

      {/* Main */}
      <main className="flex-1 flex flex-col min-w-0">
        <header className="sticky top-0 z-20 bg-gray-950/80 backdrop-blur border-b border-gray-800 px-4 py-3 lg:px-6 flex items-center gap-3">
          <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-2 hover:bg-gray-800 rounded-lg"><Menu size={20} /></button>
          <h2 className="font-semibold text-gray-200 capitalize">{navItems.find(n => n.key === page)?.label}</h2>
        </header>
        <div className="flex-1 overflow-y-auto p-4 lg:p-6">{renderPage()}</div>
      </main>
    </div>
  );
}
